/*19.Write a C program to implement single level directory structure.*/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

struct {
    char dname[10], fname[10][10];
    int fcnt;
} dir;

int main() {
    int i, ch;
    char f[10];
    dir.fcnt = 0;

    printf("\nEnter name of directory: ");
    scanf("%s", dir.dname);

    while (1) {
        printf("\n1. Create File\t2. Delete File\t3. Search File\n4. View Files\t5. Exit\nEnter your choice: ");
        scanf("%d", &ch);

        switch (ch) {
            case 1:
                printf("\nEnter the name of the file: ");
                scanf("%s", dir.fname[dir.fcnt]);
                dir.fcnt++;
                break;

            case 2:
                printf("\nEnter the name of the file to delete: ");
                scanf("%s", f);
                for (i = 0; i < dir.fcnt; i++) {
                    if (strcmp(f, dir.fname[i]) == 0) {
                        printf("File %s is deleted", f);
                        strcpy(dir.fname[i], dir.fname[dir.fcnt - 1]);
                        dir.fcnt--;
                        goto jmp;
                    }
                }
                printf("File %s not found", f);
                jmp: break;

            case 3:
                printf("\nEnter the name of the file to search: ");
                scanf("%s", f);
                for (i = 0; i < dir.fcnt; i++) {
                    if (strcmp(f, dir.fname[i]) == 0) {
                        printf("File %s is found", f);
                        goto jmp1;
                    }
                }
                printf("File %s not found", f);
                jmp1: break;

            case 4:
                if (dir.fcnt == 0)
                    printf("\nDirectory Empty");
                else {
                    printf("\nThe Files are: ");
                    for (i = 0; i < dir.fcnt; i++)
                        printf("\t%s", dir.fname[i]);
                }
                break;

            default:
                exit(0);
        }
    }
    return 0;
}
/*Enter name of directory: MyDir

1. Create File  2. Delete File  3. Search File
4. View Files   5. Exit
Enter your choice: 1
Enter the name of the file: file1

1. Create File  2. Delete File  3. Search File
4. View Files   5. Exit
Enter your choice: 4
The Files are:  file1

1. Create File  2. Delete File  3. Search File
4. View Files   5. Exit
Enter your choice: 5*/