/*3. Write a C program to implement priority scheduling algorithm.*/
#include <stdio.h>

int main() {
    int bt[20], p[20], pri[20], wt[20], tat[20], n, i, j, temp;
    float avg_wt, avg_tat;

    printf("Enter number of processes: ");
    scanf("%d", &n);

    for(i = 0; i < n; i++) {
        p[i] = i + 1; // Process Number
        printf("P%d Burst Time & Priority: ", i + 1);
        scanf("%d %d", &bt[i], &pri[i]);
    }

    // Sorting processes based on Priority (Ascending order)
    for(i = 0; i < n; i++) {
        for(j = i + 1; j < n; j++) {
            if(pri[i] > pri[j]) {
                // Swap Priority
                temp = pri[i]; pri[i] = pri[j]; pri[j] = temp;
                // Swap Burst Time
                temp = bt[i]; bt[i] = bt[j]; bt[j] = temp;
                // Swap Process ID
                temp = p[i]; p[i] = p[j]; p[j] = temp;
            }
        }
    }

    // Calculate Waiting Time (WT)
    wt[0] = 0;
    for(i = 1; i < n; i++) {
        wt[i] = wt[i - 1] + bt[i - 1];
    }

    // Calculate Turnaround Time (TAT) and Averages
    printf("\nProcess\tBT\tPriority\tWT\tTAT\n");
    float total_wt = 0, total_tat = 0;
    for(i = 0; i < n; i++) {
        tat[i] = bt[i] + wt[i];
        total_wt += wt[i];
        total_tat += tat[i];
        printf("P%d\t%d\t%d\t\t%d\t%d\n", p[i], bt[i], pri[i], wt[i], tat[i]);
    }

    printf("\nAverage Waiting Time: %.2f", total_wt / n);
    printf("\nAverage Turnaround Time: %.2f\n", total_tat / n);

    return 0;
}
/*Enter number of processes: 3
P1 Burst Time & Priority: 10 2
P2 Burst Time & Priority: 5 1
P3 Burst Time & Priority: 8 3

Process  BT      Priority        WT      TAT
P2       5       1               0       5
P1       10      2               5       15
P3       8       3               15      23

Average Waiting Time: 6.67
Average Turnaround Time: 14.33*/