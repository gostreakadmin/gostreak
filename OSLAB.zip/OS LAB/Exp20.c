/*20. Write a C program to implement Linked file allocation method*/
#include <stdio.h>
#include <stdlib.h>

void main() {
    int f[50], p, i, st, len, j, c;

    // Initialize all blocks as free (0)
    for (i = 0; i < 50; i++) f[i] = 0;

    printf("Enter how many blocks already allocated: ");
    scanf("%d", &p);
    
    if (p > 0) {
        printf("Enter blocks already allocated: ");
        for (i = 0; i < p; i++) {
            scanf("%d", &st);
            f[st] = 1; // Mark blocks as busy
        }
    }

    while (1) {
        printf("\nEnter index of starting block and length: ");
        scanf("%d %d", &st, &len);
        
        int k = len;
        if (f[st] == 0) {
            for (j = st; j < (st + k); j++) {
                if (f[j] == 0) {
                    f[j] = 1;
                    printf("%d -> %d\n", j, f[j]);
                } else {
                    printf("%d Block is already allocated\n", j);
                    k++; // Request next block to fulfill length
                }
            }
        } else {
            printf("%d starting block is already allocated\n", st);
        }

        printf("Do you want to enter more file? (Yes-1/No-0): ");
        scanf("%d", &c);
        if (c == 0) break;
    }
}
/*Enter how many blocks already allocated: 2
Enter blocks already allocated: 2 3

Enter index of starting block and length: 5 3
5 -> 1
6 -> 1
7 -> 1
Do you want to enter more file? (Yes-1/No-0): 1

Enter index of starting block and length: 2 2
2 starting block is already allocated
Do you want to enter more file? (Yes-1/No-0): 0*/