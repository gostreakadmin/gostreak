/*18.Write a C program to implement FIFO (First in first out) page replacement algorithm*/
#include <stdio.h>

int main() {
    int i, j, n, a[50], frame[10], no, k, avail, count = 0;

    // Get the number of pages in the reference string
    printf("Enter number of pages: ");
    scanf("%d", &n);

    // Get the reference string (sequence of page requests)
    printf("Enter the reference string: ");
    for (i = 1; i <= n; i++)
        scanf("%d", &a[i]);

    // Get the number of available frames in memory
    printf("Enter number of frames: ");
    scanf("%d", &no);

    // Initialize all frames to -1 (indicating they are empty)
    for (i = 0; i < no; i++)
        frame[i] = -1;

    j = 0; // Index to keep track of the oldest page position
    printf("\nRef String\t Page Frames\n");

    for (i = 1; i <= n; i++) {
        printf("%d\t\t", a[i]);
        avail = 0; // Flag to check if page is already in memory

        // Check if the current page is already in one of the frames (Page Hit)
        for (k = 0; k < no; k++) {
            if (frame[k] == a[i])
                avail = 1;
        }

        // If page is not available (Page Fault)
        if (avail == 0) {
            frame[j] = a[i];    // Replace the oldest page
            j = (j + 1) % no;   // Move the pointer in a circular fashion
            count++;            // Increment page fault count

            // Print the current state of frames
            for (k = 0; k < no; k++)
                printf("%d  ", frame[k]);
        }
        printf("\n");
    }

    printf("\nTotal Page Faults: %d\n", count);
    return 0;
}
/*Enter number of pages: 6
Enter the reference string: 7 0 1 2 0 3
Enter number of frames: 3

Ref String	 Page Frames
7		7  -1  -1  
0		7  0  -1  
1		7  0  1  
2		2  0  1  
0		
3		2  3  1  

Total Page Faults: 5*/