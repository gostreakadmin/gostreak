/*15. Write a C program to implement various memory allocation using first fit.*/
#include <stdio.h>

void main() {
    int bsize[10], psize[10], bno, pno, flags[10], allocation[10], i, j;

    // Initialize flags and allocation arrays
    for (i = 0; i < 10; i++) {
        flags[i] = 0;
        allocation[i] = -1;
    }

    printf("Enter number of blocks: ");
    scanf("%d", &bno);
    printf("Enter size of each block: ");
    for (i = 0; i < bno; i++)
        scanf("%d", &bsize[i]);

    printf("\nEnter number of processes: ");
    scanf("%d", &pno);
    printf("Enter size of each process: ");
    for (i = 0; i < pno; i++)
        scanf("%d", &psize[i]);

    // First Fit Logic
    for (i = 0; i < pno; i++) {         // Iterate through each process
        for (j = 0; j < bno; j++) {     // Search through blocks from the start
            if (flags[j] == 0 && bsize[j] >= psize[j]) {
                // Allocate block j to process i
                allocation[i] = j;
                flags[j] = 1;           // Mark block as allocated
                break;                  // Move to the next process immediately
            }
        }
    }

    // Display Results
    printf("\nProcess No.\tProcess Size\tBlock No.\n");
    for (i = 0; i < pno; i++) {
        printf("%d\t\t%d\t\t", i + 1, psize[i]);
        if (allocation[i] != -1)
            printf("%d\n", allocation[i] + 1);
        else
            printf("Not Allocated\n");
    }
}
/*Enter number of blocks: 5
Enter size of each block: 100 500 200 300 600

Enter number of processes: 4
Enter size of each process: 212 417 112 426

Process No.     Process Size    Block No.
1               212             2
2               417             5
3               112             3
4               426             Not Allocated*/