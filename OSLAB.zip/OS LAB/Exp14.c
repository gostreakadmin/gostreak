/*14. Write a C program to implement of Threading and Synchronization.*/
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

// Shared variable
int counter = 0;

// Mutex to synchronize access to the counter
pthread_mutex_t lock;

void* try_this(void* arg) {
    // Locking the critical section
    pthread_mutex_lock(&lock);

    unsigned long i = 0;
    counter += 1;
    printf("\n Job %d started\n", counter);

    for (i = 0; i < (0xFFFFFFFF); i++); // Simulating some work

    printf("\n Job %d finished\n", counter);

    // Unlocking the critical section
    pthread_mutex_unlock(&lock);

    return NULL;
}

int main(void) {
    int i = 0;
    int err;
    pthread_t tid[2];

    if (pthread_mutex_init(&lock, NULL) != 0) {
        printf("\n Mutex init failed\n");
        return 1;
    }

    while (i < 2) {
        err = pthread_create(&(tid[i]), NULL, &try_this, NULL);
        if (err != 0)
            printf("\nCan't create thread :[%d]", err);
        i++;
    }

    pthread_join(tid[0], NULL);
    pthread_join(tid[1], NULL);
    pthread_mutex_destroy(&lock);

    return 0;
}
/*Job 1 started
 Job 1 finished

 Job 2 started
 Job 2 finished*/