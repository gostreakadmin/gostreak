/*6. Write a C program to implement the Producer & consumer Problem (Semaphore)*/
#include <stdio.h>
#include <stdlib.h>

// Initialize semaphore variables
// mutex: controls access to the buffer (1 = free, 0 = busy)
// full: counts number of slots filled with data
// empty: counts number of remaining empty slots
int mutex = 1, full = 0, empty = 3, x = 0;

void producer() {
    --mutex;  // Lock the buffer
    ++full;   // Increment full slots
    --empty;  // Decrement empty slots
    x++;      // Produce an item
    printf("\nProducer produces item %d", x);
    ++mutex;  // Unlock the buffer
}

void consumer() {
    --mutex;  // Lock the buffer
    --full;   // Decrement full slots
    ++empty;  // Increment empty slots
    printf("\nConsumer consumes item %d", x);
    x--;      // Consume the item
    ++mutex;  // Unlock the buffer
}

int main() {
    int n;
    printf("\n--- Producer Consumer Problem ---");
    printf("\nBuffer Size: 3");

    while (1) {
        printf("\n\n1. Producer\n2. Consumer\n3. Exit");
        printf("\nEnter your choice: ");
        scanf("%d", &n);

        switch (n) {
            case 1:
                // Check if buffer is not full (empty slots > 0)
                if ((mutex == 1) && (empty != 0)) {
                    producer();
                } else {
                    printf("\nBuffer is full!");
                }
                break;

            case 2:
                // Check if buffer is not empty (full slots > 0)
                if ((mutex == 1) && (full != 0)) {
                    consumer();
                } else {
                    printf("\nBuffer is empty!");
                }
                break;

            case 3:
                exit(0);
                break;
        }
    }
    return 0;
}
/*--- Producer Consumer Problem ---
Buffer Size: 3

1. Producer
2. Consumer
3. Exit
Enter your choice: 1
Producer produces item 1

Enter your choice: 1
Producer produces item 2

Enter your choice: 2
Consumer consumes item 2

Enter your choice: 2
Consumer consumes item 1

Enter your choice: 2
Buffer is empty!

Enter your choice: 3*/