/*9. Write a C program for First come first serve (FCFS) scheduling algorithm.*/
#include <stdio.h>

int main() {
    int bt[20], wt[20], tat[20], n, i;
    float avg_wt = 0, avg_tat = 0;

    printf("Enter number of processes: ");
    scanf("%d", &n);

    printf("Enter Burst Time for each process:\n");
    for(i = 0; i < n; i++) {
        printf("P%d: ", i + 1);
        scanf("%d", &bt[i]);
    }

    // Waiting Time (WT) calculation
    // First process always has a waiting time of 0
    wt[0] = 0; 
    for(i = 1; i < n; i++) {
        wt[i] = wt[i - 1] + bt[i - 1];
    }

    printf("\nProcess\tBurst Time\tWaiting Time\tTurnaround Time\n");

    // Turnaround Time (TAT) calculation and printing results
    for(i = 0; i < n; i++) {
        tat[i] = bt[i] + wt[i];
        avg_wt += wt[i];
        avg_tat += tat[i];
        printf("P%d\t%d\t\t%d\t\t%d\n", i + 1, bt[i], wt[i], tat[i]);
    }

    avg_wt /= n;
    avg_tat /= n;

    printf("\nAverage Waiting Time: %.2f", avg_wt);
    printf("\nAverage Turnaround Time: %.2f\n", avg_tat);

    return 0;
}
/*Enter number of processes: 3
Enter Burst Time for each process:
P1: 24
P2: 3
P3: 3

Process Burst Time      Waiting Time    Turnaround Time
P1      24              0               24
P2      3               24              27
P3      3               27              30

Average Waiting Time: 17.00
Average Turnaround Time: 27.00*/