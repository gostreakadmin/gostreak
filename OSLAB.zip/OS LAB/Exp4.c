/*4 Write a C program to implement SJF (Shortest Job First) scheduling algorithm.*/
#include <stdio.h>

int main() {
    int bt[20], p[20], wt[20], tat[20], n, i, j, temp;
    float avg_wt, avg_tat, total_wt = 0, total_tat = 0;

    printf("Enter number of processes: ");
    scanf("%d", &n);

    for(i = 0; i < n; i++) {
        p[i] = i + 1; // Process Number
        printf("P%d Burst Time: ", i + 1);
        scanf("%d", &bt[i]);
    }

    // Sorting processes based on Burst Time (Ascending order)
    for(i = 0; i < n; i++) {
        for(j = i + 1; j < n; j++) {
            if(bt[i] > bt[j]) {
                // Swap Burst Time
                temp = bt[i]; bt[i] = bt[j]; bt[j] = temp;
                // Swap Process ID
                temp = p[i]; p[i] = p[j]; p[j] = temp;
            }
        }
    }

    // Calculate Waiting Time (WT)
    wt[0] = 0; // First process has no waiting time
    for(i = 1; i < n; i++) {
        wt[i] = wt[i - 1] + bt[i - 1];
    }

    // Calculate Turnaround Time (TAT)
    printf("\nProcess\tBurst Time\tWaiting Time\tTurnaround Time\n");
    for(i = 0; i < n; i++) {
        tat[i] = bt[i] + wt[i];
        total_wt += wt[i];
        total_tat += tat[i];
        printf("P%d\t%d\t\t%d\t\t%d\n", p[i], bt[i], wt[i], tat[i]);
    }

    avg_wt = total_wt / n;
    avg_tat = total_tat / n;

    printf("\nAverage Waiting Time: %.2f", avg_wt);
    printf("\nAverage Turnaround Time: %.2f\n", avg_tat);

    return 0;
}
/*Enter number of processes: 3
P1 Burst Time: 6
P2 Burst Time: 2
P3 Burst Time: 8

Process Burst Time      Waiting Time    Turnaround Time
P2      2               0               2
P1      6               2               8
P3      8               8               16

Average Waiting Time: 3.33
Average Turnaround Time: 8.67*/