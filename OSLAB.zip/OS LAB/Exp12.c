/*12.Write a C program to implement Inter process communication using pipes*/
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <string.h>
#include <stdlib.h>

int main() {
    int fd[2]; // fd[0] is for reading, fd[1] is for writing
    pid_t pid;
    char write_msg[] = "Hello from Child!";
    char read_msg[20];

    // 1. Create the pipe
    if (pipe(fd) == -1) {
        fprintf(stderr, "Pipe failed");
        return 1;
    }

    // 2. Fork a process
    pid = fork();

    if (pid < 0) {
        fprintf(stderr, "Fork failed");
        return 1;
    }

    if (pid == 0) {
        // --- CHILD PROCESS ---
        // Close the unused read end
        close(fd[0]);

        // 3. Write message to the pipe
        write(fd[1], write_msg, strlen(write_msg) + 1);
        printf("[Child] Sent message to Parent: %s\n", write_msg);

        // Close the write end after sending
        close(fd[1]);
        exit(0);
    } else {
        // --- PARENT PROCESS ---
        // Close the unused write end
        close(fd[1]);

        // 4. Read message from the pipe
        read(fd[0], read_msg, sizeof(read_msg));
        printf("[Parent] Received message from Child: %s\n", read_msg);

        // Close the read end
        close(fd[0]);
    }

    return 0;
}
/*[Child] Sent message to Parent: Hello from Child!
[Parent] Received message from Child: Hello from Child!*/