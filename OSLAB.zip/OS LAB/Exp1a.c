/*1. i)Write a C program to implement the System Calls opendir, readdir, Fork, Getpid*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <dirent.h>

int main() {
    pid_t pid;

    // 1. Fork System Call: Creates a new process
    pid = fork();

    if (pid < 0) {
        // Error handling
        fprintf(stderr, "Fork Failed\n");
        return 1;
    } 
    else if (pid == 0) {
        // --- CHILD PROCESS ---
        printf("\n[Child] Child Process Started.");
        
        // 2. Getpid System Call: Returns the process ID of the child
        printf("\n[Child] Child PID: %d", getpid());
        printf("\n[Child] Parent PID: %d\n", getppid());

        // 3. Opendir System Call: Opens the current directory stream
        struct dirent *entry;
        DIR *dp = opendir("."); 

        if (dp == NULL) {
            perror("opendir");
            return 1;
        }

        printf("[Child] Contents of current directory:\n");

        // 4. Readdir System Call: Reads and lists the directory contents
        while ((entry = readdir(dp)) != NULL) {
            printf("  - %s\n", entry->d_name);
        }

        closedir(dp);
        printf("[Child] Process finishing...\n");
    } 
    else {
        // --- PARENT PROCESS ---
        printf("[Parent] Parent Process Started.");
        printf("\n[Parent] Parent PID: %d", getpid());
        printf("\n[Parent] Created Child with PID: %d\n", pid);
        
        // Wait for child to finish to avoid zombie processes
        wait(NULL); 
        printf("\n[Parent] Child has finished. Parent exiting.\n");
    }

    return 0;
}
/*output
[Parent] Parent Process Started.
[Parent] Parent PID: 4520
[Parent] Created Child with PID: 4521

[Child] Child Process Started.
[Child] Child PID: 4521
[Child] Parent PID: 4520
[Child] Contents of current directory:
  - .
  - ..
  - Exp1a.c
  - Exp1a
[Child] Process finishing...

[Parent] Child has finished. Parent exiting.*/