/*11.Write a C program to implement Producer consumer problem using Semaphores*/
#include <stdio.h>
#include <stdlib.h>

/* mutex: Ensures mutual exclusion (only one process accesses buffer)
   full: Tracks filled slots
   empty: Tracks available slots
   x: The item being produced/consumed
*/
int mutex = 1, full = 0, empty = 3, x = 0;

void producer() {
    --mutex;  // Wait (Lock)
    ++full;   // Signal full
    --empty;  // Wait empty
    x++;
    printf("\nProducer produces item %d", x);
    ++mutex;  // Signal (Unlock)
}

void consumer() {
    --mutex;  // Wait (Lock)
    --full;   // Wait full
    ++empty;  // Signal empty
    printf("\nConsumer consumes item %d", x);
    x--;
    ++mutex;  // Signal (Unlock)
}

int main() {
    int n;
    printf("\n--- Producer Consumer Problem (Semaphore) ---");
    printf("\nBuffer Size: 3\n");

    while (1) {
        printf("\n1. Producer\n2. Consumer\n3. Exit");
        printf("\nEnter choice: ");
        scanf("%d", &n);

        switch (n) {
            case 1:
                if ((mutex == 1) && (empty != 0)) {
                    producer();
                } else {
                    printf("\nBuffer is full!");
                }
                break;
            case 2:
                if ((mutex == 1) && (full != 0)) {
                    consumer();
                } else {
                    printf("\nBuffer is empty!");
                }
                break;
            case 3:
                exit(0);
                break;
        }
    }
    return 0;
}
/*--- Producer Consumer Problem (Semaphore) ---
Buffer Size: 3

1. Producer
2. Consumer
3. Exit
Enter choice: 1
Producer produces item 1

Enter choice: 1
Producer produces item 2

Enter choice: 2
Consumer consumes item 2

Enter choice: 3*/