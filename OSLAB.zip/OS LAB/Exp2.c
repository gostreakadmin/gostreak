/*2. Write programs using the following system calls of UNIX operating system: fork, exec, getpid,exit, wait, close, stat, opendir, readdir.*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <dirent.h>

int main() {
    pid_t pid;
    struct stat file_stat;

    // 1. Stat System Call: Get file information
    if (stat("Exp1a.c", &file_stat) == 0) {
        printf("File 'Exp1a.c' Size: %ld bytes\n", file_stat.st_size);
    }

    // 2. Fork System Call
    pid = fork();

    if (pid < 0) {
        printf("Fork Failed\n");
        exit(1); // 3. Exit System Call
    } 
    else if (pid == 0) {
        // --- CHILD PROCESS ---
        printf("\n[Child] PID: %d. Executing 'ls' command...\n", getpid()); // 4. Getpid

        // 5. Exec System Call: Replace child process with 'ls'
        // execlp(command, command_name, argument, NULL)
        execlp("ls", "ls", "-l", NULL); 
        
        // This line only runs if exec fails
        perror("exec failed");
        exit(1);
    } 
    else {
        // --- PARENT PROCESS ---
        // 6. Wait System Call: Wait for child to finish exec
        wait(NULL);
        printf("\n[Parent] Child process finished.\n");

        // 7. Opendir & Readdir System Calls
        DIR *dir = opendir(".");
        struct dirent *entry;
        printf("[Parent] Manual directory listing:\n");
        while ((entry = readdir(dir)) != NULL) {
            printf("  %s\n", entry->d_name);
        }

        // 8. Close / Closedir System Call
        closedir(dir);
        printf("[Parent] Directory stream closed. Exiting.\n");
    }

    return 0;
}
/*File 'Exp1a.c' Size: 1240 bytes

[Child] PID: 4600. Executing 'ls' command...
(List of files in long format provided by the actual 'ls' command)

[Parent] Child process finished.
[Parent] Manual directory listing:
  .
  ..
  Exp1a.c
  Exp2.c
[Parent] Directory stream closed. Exiting.*/