/*5. Write a C program to simulate UNIX commands like cp, ls, grep*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>

void simulate_ls() {
    struct dirent *de;
    DIR *dr = opendir(".");
    if (dr == NULL) {
        printf("Could not open directory\n");
        return;
    }
    printf("\n--- ls Output ---\n");
    while ((de = readdir(dr)) != NULL) {
        printf("%s\n", de->d_name);
    }
    closedir(dr);
}

void simulate_cp() {
    char source_fn[30], dest_fn[30], ch;
    FILE *src, *dst;
    printf("Enter source file: ");
    scanf("%s", source_fn);
    printf("Enter destination file: ");
    scanf("%s", dest_fn);

    src = fopen(source_fn, "r");
    if (src == NULL) {
        printf("Error: Source file not found.\n");
        return;
    }
    dst = fopen(dest_fn, "w");
    while ((ch = fgetc(src)) != EOF) {
        fputc(ch, dst);
    }
    printf("File copied successfully.\n");
    fclose(src);
    fclose(dst);
}

void simulate_grep() {
    char fn[30], pat[30], line[200];
    FILE *fp;
    printf("Enter file name: ");
    scanf("%s", fn);
    printf("Enter pattern to search: ");
    scanf("%s", pat);

    fp = fopen(fn, "r");
    if (fp == NULL) {
        printf("Error: File not found.\n");
        return;
    }
    printf("\n--- grep Results ---\n");
    while (fgets(line, sizeof(line), fp)) {
        if (strstr(line, pat)) {
            printf("%s", line);
        }
    }
    fclose(fp);
}

int main() {
    int choice;
    while(1) {
        printf("\n--- UNIX Command Simulator ---\n");
        printf("1. ls (List Files)\n");
        printf("2. cp (Copy File)\n");
        printf("3. grep (Search Pattern)\n");
        printf("4. Exit\n");
        printf("Enter choice: ");
        scanf("%d", &choice);

        switch(choice) {
            case 1: simulate_ls(); break;
            case 2: simulate_cp(); break;
            case 3: simulate_grep(); break;
            case 4: exit(0);
            default: printf("Invalid choice!\n");
        }
    }
    return 0;
}
/*--- UNIX Command Simulator ---
1. ls (List Files)
2. cp (Copy File)
3. grep (Search Pattern)
4. Exit
Enter choice: 1

--- ls Output ---
.
..
Exp1a.c
Exp5.c

Enter choice: 2
Enter source file: Exp1a.c
Enter destination file: backup.c
File copied successfully.

Enter choice: 3
Enter file name: Exp1a.c
Enter pattern to search: fork

--- grep Results ---
    pid = fork();

Enter choice: 4*/