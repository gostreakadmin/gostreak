/*7. Write a c program to implement C-SCAN disk scheduling algorithm.*/
#include <stdio.h>
#include <stdlib.h>

int main() {
    int queue[20], n, head, max, i, j, temp, seek = 0;
    int left[20], right[20], l_count = 0, r_count = 0;

    printf("Enter the maximum range of disk: ");
    scanf("%d", &max);
    printf("Enter the current head position: ");
    scanf("%d", &head);
    printf("Enter the number of requests: ");
    scanf("%d", &n);

    printf("Enter the request queue: ");
    for (i = 0; i < n; i++) {
        scanf("%d", &temp);
        if (temp >= head) {
            right[r_count++] = temp;
        } else {
            left[l_count++] = temp;
        }
    }

    // Sorting both arrays
    for (i = 0; i < r_count - 1; i++) {
        for (j = i + 1; j < r_count; j++) {
            if (right[i] > right[j]) {
                temp = right[i]; right[i] = right[j]; right[j] = temp;
            }
        }
    }
    for (i = 0; i < l_count - 1; i++) {
        for (j = i + 1; j < l_count; j++) {
            if (left[i] > left[j]) {
                temp = left[i]; left[i] = left[j]; left[j] = temp;
            }
        }
    }

    printf("\nOrder of service: %d", head);

    // Service requests to the right (towards the end)
    for (i = 0; i < r_count; i++) {
        printf(" -> %d", right[i]);
    }
    
    // Move to the end of the disk
    printf(" -> %d", max);
    
    // Jump to the beginning of the disk
    printf(" -> 0");
    
    // Service requests from the beginning up to the starting head
    for (i = 0; i < l_count; i++) {
        printf(" -> %d", left[i]);
    }

    // Calculation of Total Seek Time
    // Logic: (max - head) + (max - 0) + (last_request_on_left - 0)
    seek = (max - head) + (max - 0) + left[l_count - 1];

    printf("\n\nTotal Seek Operations: %d\n", seek);

    return 0;
}
/*Enter the maximum range of disk: 199
Enter the current head position: 50
Enter the number of requests: 7
Enter the request queue: 82 170 43 140 24 16 190

Order of service: 50 -> 82 -> 140 -> 170 -> 190 -> 199 -> 0 -> 16 -> 24 -> 43

Total Seek Operations: 391 */