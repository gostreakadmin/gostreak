/*ii) Write a C program to simulate the operation of ls and grep commands in Unix*/
#include <stdio.h>
#include <dirent.h>

int main() {
    struct dirent *de; 
    DIR *dr = opendir("."); // Open current directory [cite: 1]

    if (dr == NULL) {
        printf("Could not open directory\n");
        return 1;
    }

    printf("Simulated 'ls' Output:\n");
    
    // readdir gets one file at a time until it returns NULL [cite: 1, 6]
    while ((de = readdir(dr)) != NULL) {
        printf("%s\n", de->d_name);
    }

    closedir(dr);     
    return 0;
}

/*Simulated 'ls' Output:
.
..
Exp1a.c
Exp1b.c
test.txt*/