/*8 . Write a C program to implement shared memory and inter process communication.*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/types.h>

int main() {
    int shmid;
    void *shared_memory;
    char buffer[100];
    
    // 1. Create a shared memory segment
    // key: 2345, size: 1024 bytes, permissions: 0666 (Read/Write)
    shmid = shmget((key_t)2345, 1024, 0666 | IPC_CREAT);
    
    printf("Key of shared memory is %d\n", shmid);

    // 2. Attach the process to the shared memory segment
    shared_memory = shmat(shmid, NULL, 0);
    
    printf("Process attached at %p\n", shared_memory);

    // 3. Write data to the shared memory
    printf("Enter data to write to shared memory: ");
    fgets(buffer, 100, stdin);
    strcpy(shared_memory, buffer);
    
    printf("Data written: %s\n", (char *)shared_memory);

    // 4. Detach the process from shared memory
    shmdt(shared_memory);

    return 0;
}
/*Key of shared memory is 32768
Process attached at 0x7f8e1a2b3c4d
Enter data to write to shared memory: Hello from Gagan
Data written: Hello from Gagan*/