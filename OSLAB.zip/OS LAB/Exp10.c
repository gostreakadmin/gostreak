/*10. Write a C program to implement Round Robin (RR) scheduling algorithm*/
#include <stdio.h>

int main() {
    int i, n, time, remain, flag = 0, time_quantum;
    int wait_time = 0, turnaround_time = 0, at[10], bt[10], rt[10];

    printf("Enter Total Process: ");
    scanf("%d", &n);
    remain = n;

    for (i = 0; i < n; i++) {
        printf("Enter Arrival Time and Burst Time for Process Process[%d]: ", i + 1);
        scanf("%d %d", &at[i], &bt[i]);
        rt[i] = bt[i]; // rt stores the remaining time
    }

    printf("Enter Time Quantum: ");
    scanf("%d", &time_quantum);

    printf("\nProcess\t|Turnaround Time|Waiting Time\n\n");
    
    // Core Round Robin Logic
    for (time = 0, i = 0; remain != 0;) {
        if (rt[i] <= time_quantum && rt[i] > 0) {
            time += rt[i];
            rt[i] = 0;
            flag = 1;
        } else if (rt[i] > 0) {
            rt[i] -= time_quantum;
            time += time_quantum;
        }

        if (rt[i] == 0 && flag == 1) {
            remain--;
            printf("P[%d]\t|\t%d\t|\t%d\n", i + 1, time - at[i], time - at[i] - bt[i]);
            wait_time += time - at[i] - bt[i];
            turnaround_time += time - at[i];
            flag = 0;
        }

        if (i == n - 1)
            i = 0;
        else if (at[i + 1] <= time)
            i++;
        else
            i = 0;
    }

    printf("\nAverage Waiting Time = %.2f\n", wait_time * 1.0 / n);
    printf("Average Turnaround Time = %.2f\n", turnaround_time * 1.0 / n);

    return 0;
}
/*Enter Total Process: 3
Enter Arrival Time and Burst Time for Process Process[1]: 0 10
Enter Arrival Time and Burst Time for Process Process[2]: 0 5
Enter Arrival Time and Burst Time for Process Process[3]: 0 8
Enter Time Quantum: 2

Process |Turnaround Time|Waiting Time

P[2]    |       13      |       8
P[3]    |       21      |       13
P[1]    |       23      |       13

Average Waiting Time = 11.33
Average Turnaround Time = 15.67*/