-- 15 Develop software for Eservices in Revenue department.

-- ==========================================
-- 1. DDL: Create Tables for E-services
-- ==========================================
CREATE TABLE Citizen (
    Aadhar_No VARCHAR(12) PRIMARY KEY,
    Full_Name VARCHAR(100) NOT NULL,
    Phone_No VARCHAR(15) UNIQUE,
    Address VARCHAR(255)
);

CREATE TABLE Service_Master (
    Service_ID INT PRIMARY KEY,
    Service_Name VARCHAR(100) NOT NULL,
    Fee_Amount DECIMAL(10, 2) CHECK (Fee_Amount >= 0)
);

CREATE TABLE E_Application (
    App_No INT PRIMARY KEY,
    Aadhar_No VARCHAR(12),
    Service_ID INT,
    Apply_Date DATE,
    Status VARCHAR(20) DEFAULT 'Pending' CHECK (Status IN ('Pending', 'Approved', 'Rejected', 'Processing')),
    Remarks VARCHAR(255),
    FOREIGN KEY (Aadhar_No) REFERENCES Citizen(Aadhar_No),
    FOREIGN KEY (Service_ID) REFERENCES Service_Master(Service_ID)
);

-- ==========================================
-- 2. DML: Insert Citizens, Services, and Applications
-- ==========================================
-- Register Citizens
INSERT INTO Citizen VALUES ('123456789012', 'Arun Kumar', '9876543210', '12 North Street, City');
INSERT INTO Citizen VALUES ('987654321098', 'Meena Kumari', '9988776655', '45 South Avenue, City');

-- Available Government Services
INSERT INTO Service_Master VALUES (1, 'Income Certificate', 50.00);
INSERT INTO Service_Master VALUES (2, 'Community Certificate', 100.00);
INSERT INTO Service_Master VALUES (3, 'Nativity Certificate', 75.00);

-- Citizens applying for certificates
INSERT INTO E_Application VALUES (1001, '123456789012', 1, DATE '2023-10-01', 'Pending', NULL);
INSERT INTO E_Application VALUES (1002, '987654321098', 2, DATE '2023-10-05', 'Pending', NULL);

-- ==========================================
-- 3. PL/SQL: Application Logic (Officer updates status)
-- ==========================================
SET SERVEROUTPUT ON;

CREATE OR REPLACE PROCEDURE Update_Application_Status(
    p_App_No INT,
    p_New_Status VARCHAR,
    p_Remarks VARCHAR
)
IS
    v_Current_Status VARCHAR(20);
    v_Citizen_Name VARCHAR(100);
    v_Service_Name VARCHAR(100);
BEGIN
    -- 1. Get application details
    SELECT a.Status, c.Full_Name, s.Service_Name
    INTO v_Current_Status, v_Citizen_Name, v_Service_Name
    FROM E_Application a
    JOIN Citizen c ON a.Aadhar_No = c.Aadhar_No
    JOIN Service_Master s ON a.Service_ID = s.Service_ID
    WHERE a.App_No = p_App_No;

    -- 2. Application Logic: Only allow updates if not already finalized
    IF v_Current_Status = 'Pending' OR v_Current_Status = 'Processing' THEN
        
        UPDATE E_Application
        SET Status = p_New_Status,
            Remarks = p_Remarks
        WHERE App_No = p_App_No;

        COMMIT;
        DBMS_OUTPUT.PUT_LINE('SUCCESS: Application ' || p_App_No || ' for ' || v_Service_Name || ' (' || v_Citizen_Name || ') is now ' || p_New_Status || '.');
        DBMS_OUTPUT.PUT_LINE('Officer Remarks: ' || p_Remarks);
        
    ELSE
        DBMS_OUTPUT.PUT_LINE('WARNING: Application ' || p_App_No || ' is already ' || v_Current_Status || ' and cannot be changed.');
    END IF;

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('ERROR: Application Number ' || p_App_No || ' not found in the system.');
END;
/

