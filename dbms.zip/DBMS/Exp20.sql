-- 20 Develop the application software for online trading systems.

-- ==========================================
-- 1. DDL: Create Tables
-- ==========================================
CREATE TABLE Trader (
    Trader_ID INT PRIMARY KEY,
    Trader_Name VARCHAR(50) NOT NULL,
    Wallet_Balance DECIMAL(15, 2) CHECK (Wallet_Balance >= 0)
);

CREATE TABLE Stock (
    Stock_ID INT PRIMARY KEY,
    Ticker_Symbol VARCHAR(10) UNIQUE,
    Current_Price DECIMAL(10, 2)
);

CREATE TABLE Portfolio (
    Trader_ID INT,
    Stock_ID INT,
    Quantity INT CHECK (Quantity >= 0),
    PRIMARY KEY (Trader_ID, Stock_ID),
    FOREIGN KEY (Trader_ID) REFERENCES Trader(Trader_ID),
    FOREIGN KEY (Stock_ID) REFERENCES Stock(Stock_ID)
);

CREATE TABLE Trade_History (
    Trade_ID INT PRIMARY KEY,
    Trader_ID INT,
    Stock_ID INT,
    Trade_Type VARCHAR(10) CHECK (Trade_Type IN ('BUY', 'SELL')),
    Quantity INT,
    Trade_Price DECIMAL(10, 2),
    Trade_Date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ==========================================
-- 2. DML: Insert Initial Data
-- ==========================================
INSERT INTO Trader VALUES (1001, 'Alex Mercer', 50000.00);
INSERT INTO Trader VALUES (1002, 'Sarah Connor', 15000.00);

INSERT INTO Stock VALUES (1, 'AAPL', 150.00);
INSERT INTO Stock VALUES (2, 'GOOGL', 2800.00);
INSERT INTO Stock VALUES (3, 'TSLA', 250.00);

INSERT INTO Portfolio VALUES (1001, 1, 50);

-- ==========================================
-- 3. PL/SQL: Application Logic (Buy Order)
-- ==========================================
SET SERVEROUTPUT ON;

CREATE OR REPLACE PROCEDURE Execute_Buy_Order(
    p_Trader_ID INT,
    p_Stock_ID INT,
    p_Quantity INT
) 
IS
    v_Current_Price DECIMAL(10, 2);
    v_Total_Cost DECIMAL(15, 2);
    v_Balance DECIMAL(15, 2);
    v_Portfolio_Check INT;
BEGIN
    SELECT Current_Price INTO v_Current_Price FROM Stock WHERE Stock_ID = p_Stock_ID;
    v_Total_Cost := v_Current_Price * p_Quantity;

    SELECT Wallet_Balance INTO v_Balance FROM Trader WHERE Trader_ID = p_Trader_ID;

    IF v_Balance >= v_Total_Cost THEN
        UPDATE Trader 
        SET Wallet_Balance = Wallet_Balance - v_Total_Cost 
        WHERE Trader_ID = p_Trader_ID;

        SELECT COUNT(*) INTO v_Portfolio_Check 
        FROM Portfolio 
        WHERE Trader_ID = p_Trader_ID AND Stock_ID = p_Stock_ID;

        IF v_Portfolio_Check > 0 THEN
            UPDATE Portfolio 
            SET Quantity = Quantity + p_Quantity 
            WHERE Trader_ID = p_Trader_ID AND Stock_ID = p_Stock_ID;
        ELSE
            INSERT INTO Portfolio (Trader_ID, Stock_ID, Quantity) 
            VALUES (p_Trader_ID, p_Stock_ID, p_Quantity);
        END IF;

        INSERT INTO Trade_History (Trade_ID, Trader_ID, Stock_ID, Trade_Type, Quantity, Trade_Price)
        VALUES ((SELECT NVL(MAX(Trade_ID), 0) + 1 FROM Trade_History), p_Trader_ID, p_Stock_ID, 'BUY', p_Quantity, v_Current_Price);

        COMMIT;
        DBMS_OUTPUT.PUT_LINE('SUCCESS: Bought ' || p_Quantity || ' shares. Total cost: $' || v_Total_Cost);
        
    ELSE
        DBMS_OUTPUT.PUT_LINE('FAILED: Insufficient funds in wallet. Needed: $' || v_Total_Cost || ', Available: $' || v_Balance);
    END IF;
    
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('ERROR: Invalid Trader ID or Stock ID.');
END;
/