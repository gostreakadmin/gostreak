-- 13  Develop the application for an EMart Grocery Shop.

-- ==========================================
-- 1. DDL: Create Tables for EMart
-- ==========================================
CREATE TABLE EMart_Customer (
    Customer_ID INT PRIMARY KEY,
    Customer_Name VARCHAR(50) NOT NULL,
    Phone_No VARCHAR(15) UNIQUE,
    Loyalty_Points INT DEFAULT 0
);

CREATE TABLE Grocery_Item (
    Item_ID INT PRIMARY KEY,
    Item_Name VARCHAR(50) NOT NULL,
    Category VARCHAR(30),
    Unit_Price DECIMAL(10, 2) CHECK (Unit_Price > 0),
    Stock_Available INT CHECK (Stock_Available >= 0)
);

CREATE TABLE Purchase_Bill (
    Bill_ID INT PRIMARY KEY,
    Customer_ID INT,
    Bill_Date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    Total_Amount DECIMAL(10, 2),
    FOREIGN KEY (Customer_ID) REFERENCES EMart_Customer(Customer_ID)
);

CREATE TABLE Bill_Details (
    Bill_ID INT,
    Item_ID INT,
    Quantity INT CHECK (Quantity > 0),
    Subtotal DECIMAL(10, 2),
    PRIMARY KEY (Bill_ID, Item_ID),
    FOREIGN KEY (Bill_ID) REFERENCES Purchase_Bill(Bill_ID),
    FOREIGN KEY (Item_ID) REFERENCES Grocery_Item(Item_ID)
);

-- ==========================================
-- 2. DML: Insert Initial Inventory and Customers
-- ==========================================
-- Add Customers
INSERT INTO EMart_Customer (Customer_ID, Customer_Name, Phone_No) VALUES (601, 'Karthik', '9876543210');
INSERT INTO EMart_Customer (Customer_ID, Customer_Name, Phone_No) VALUES (602, 'Pooja', '9876543211');

-- Add Grocery Items
INSERT INTO Grocery_Item VALUES (101, 'Aashirvaad Atta 5kg', 'Staples', 250.00, 50);
INSERT INTO Grocery_Item VALUES (102, 'Amul Butter 500g', 'Dairy', 260.00, 30);
INSERT INTO Grocery_Item VALUES (103, 'Tata Salt 1kg', 'Staples', 25.00, 100);

-- ==========================================
-- 3. PL/SQL: Application Logic (Process Checkout)
-- ==========================================
SET SERVEROUTPUT ON;

CREATE OR REPLACE PROCEDURE Checkout_Grocery_Item(
    p_Customer_ID INT,
    p_Item_ID INT,
    p_Quantity INT
)
IS
    v_Stock INT;
    v_Price DECIMAL(10, 2);
    v_Total DECIMAL(10, 2);
    v_Bill_ID INT;
    v_Points INT;
    v_Item_Name VARCHAR(50);
BEGIN
    -- 1. Check stock and get price & item name
    SELECT Stock_Available, Unit_Price, Item_Name 
    INTO v_Stock, v_Price, v_Item_Name
    FROM Grocery_Item
    WHERE Item_ID = p_Item_ID;

    -- 2. Application Logic: Validate stock availability
    IF v_Stock >= p_Quantity THEN
        
        -- Calculate total cost
        v_Total := v_Price * p_Quantity;
        
        -- Calculate loyalty points (5 points for every Rs. 100 spent)
        v_Points := FLOOR(v_Total / 100) * 5; 

        -- Generate a new Bill ID
        SELECT NVL(MAX(Bill_ID), 2000) + 1 INTO v_Bill_ID FROM Purchase_Bill;

        -- Record the main bill
        INSERT INTO Purchase_Bill (Bill_ID, Customer_ID, Total_Amount)
        VALUES (v_Bill_ID, p_Customer_ID, v_Total);

        -- Record the individual items in the bill
        INSERT INTO Bill_Details (Bill_ID, Item_ID, Quantity, Subtotal)
        VALUES (v_Bill_ID, p_Item_ID, p_Quantity, v_Total);

        -- Deduct from physical stock
        UPDATE Grocery_Item
        SET Stock_Available = Stock_Available - p_Quantity
        WHERE Item_ID = p_Item_ID;

        -- Reward Loyalty Points to Customer
        UPDATE EMart_Customer
        SET Loyalty_Points = Loyalty_Points + v_Points
        WHERE Customer_ID = p_Customer_ID;

        COMMIT;
        DBMS_OUTPUT.PUT_LINE('SUCCESS: Sold ' || p_Quantity || 'x ' || v_Item_Name || '.');
        DBMS_OUTPUT.PUT_LINE('Bill ID: ' || v_Bill_ID || ' | Total: Rs. ' || v_Total || ' | Points Earned: ' || v_Points);
        
    ELSE
        DBMS_OUTPUT.PUT_LINE('FAILED: ' || v_Item_Name || ' is running out of stock. Only ' || v_Stock || ' units left.');
    END IF;

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('ERROR: Invalid Customer ID or Item ID.');
END;
/

