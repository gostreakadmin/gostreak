-- 12  Develop GUI based application software for Hostel Management.

-- ==========================================
-- 1. DDL: Create Tables for Hostel Management
-- ==========================================
CREATE TABLE Hostel_Room (
    Room_No VARCHAR(10) PRIMARY KEY,
    Room_Type VARCHAR(20) CHECK (Room_Type IN ('AC', 'Non-AC')),
    Total_Beds INT,
    Vacant_Beds INT CHECK (Vacant_Beds >= 0)
);

CREATE TABLE Hostel_Student (
    Student_ID INT PRIMARY KEY,
    Student_Name VARCHAR(50) NOT NULL,
    Course VARCHAR(50),
    Phone_No VARCHAR(15)
);

CREATE TABLE Room_Allocation (
    Allocation_ID INT PRIMARY KEY,
    Student_ID INT UNIQUE,       -- A student can only have one active room allocation
    Room_No VARCHAR(10),
    Date_Allocated TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (Student_ID) REFERENCES Hostel_Student(Student_ID),
    FOREIGN KEY (Room_No) REFERENCES Hostel_Room(Room_No)
);

-- ==========================================
-- 2. DML: Insert Initial Data
-- ==========================================
-- Add some rooms to the hostel
INSERT INTO Hostel_Room VALUES ('A-101', 'AC', 2, 2);      -- 2 seater, 2 vacant
INSERT INTO Hostel_Room VALUES ('A-102', 'Non-AC', 3, 3);  -- 3 seater, 3 vacant
INSERT INTO Hostel_Room VALUES ('B-201', 'AC', 1, 0);      -- 1 seater, FULL (0 vacant)

-- Add students who applied for hostel
INSERT INTO Hostel_Student VALUES (801, 'Vikram Singh', 'B.Tech CS', '9876543210');
INSERT INTO Hostel_Student VALUES (802, 'Neha Sharma', 'B.Sc Physics', '9876543211');

-- ==========================================
-- 3. PL/SQL: Application Logic (GUI "Allocate" Button)
-- ==========================================
-- This procedure acts as the code executed when the user clicks "Allocate Room" in the GUI.
SET SERVEROUTPUT ON;

CREATE OR REPLACE PROCEDURE Allocate_Hostel_Room(
    p_Student_ID INT,
    p_Room_No VARCHAR
)
IS
    v_Vacant_Beds INT;
    v_Allocation_ID INT;
    v_Already_Allocated INT;
BEGIN
    -- 1. Check if the student already has a room
    SELECT COUNT(*) INTO v_Already_Allocated 
    FROM Room_Allocation 
    WHERE Student_ID = p_Student_ID;

    IF v_Already_Allocated > 0 THEN
        DBMS_OUTPUT.PUT_LINE('FAILED: Student ' || p_Student_ID || ' is already allocated to a room.');
        RETURN;
    END IF;

    -- 2. Check if the requested room has vacancy
    SELECT Vacant_Beds INTO v_Vacant_Beds 
    FROM Hostel_Room 
    WHERE Room_No = p_Room_No;

    -- 3. Application Logic: Allocate if space is available
    IF v_Vacant_Beds > 0 THEN
        
        -- Generate a new Allocation ID
        SELECT NVL(MAX(Allocation_ID), 3000) + 1 INTO v_Allocation_ID FROM Room_Allocation;

        -- Record the allocation
        INSERT INTO Room_Allocation (Allocation_ID, Student_ID, Room_No)
        VALUES (v_Allocation_ID, p_Student_ID, p_Room_No);

        -- Decrease the vacancy in the room
        UPDATE Hostel_Room
        SET Vacant_Beds = Vacant_Beds - 1
        WHERE Room_No = p_Room_No;

        COMMIT;
        DBMS_OUTPUT.PUT_LINE('SUCCESS: Student ' || p_Student_ID || ' has been successfully allocated Room ' || p_Room_No || '.');
        
    ELSE
        DBMS_OUTPUT.PUT_LINE('FAILED: Room ' || p_Room_No || ' is fully occupied. No vacant beds.');
    END IF;

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('ERROR: Invalid Student ID or Room Number entered in the GUI.');
END;
/

