-- 18 Create software for tourism management systems.

-- ==========================================
-- 1. DDL: Create Tables for Tourism System
-- ==========================================
CREATE TABLE Tourist (
    Tourist_ID INT PRIMARY KEY,
    Tourist_Name VARCHAR(50) NOT NULL,
    Contact_Number VARCHAR(15),
    Email VARCHAR(50) UNIQUE
);

CREATE TABLE Tour_Package (
    Package_ID INT PRIMARY KEY,
    Destination VARCHAR(50) NOT NULL,
    Duration_Days INT,
    Cost DECIMAL(10, 2),
    Max_Capacity INT,                -- Total seats available on the tour
    Current_Bookings INT DEFAULT 0   -- How many people have booked so far
);

CREATE TABLE Booking (
    Booking_ID INT PRIMARY KEY,
    Tourist_ID INT,
    Package_ID INT,
    Booking_Date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (Tourist_ID) REFERENCES Tourist(Tourist_ID),
    FOREIGN KEY (Package_ID) REFERENCES Tour_Package(Package_ID)
);

-- ==========================================
-- 2. DML: Insert Initial Packages and Tourists
-- ==========================================
INSERT INTO Tourist VALUES (301, 'Michael Scott', '9876543210', 'michael@email.com');
INSERT INTO Tourist VALUES (302, 'Pam Beesly', '9876543211', 'pam@email.com');

-- Inserting Tour Packages
INSERT INTO Tour_Package VALUES (1, 'Goa Beach Holiday', 5, 15000.00, 20, 0);
INSERT INTO Tour_Package VALUES (2, 'Kerala Backwaters', 7, 25000.00, 2, 1); -- Note: Capacity is 2, currently 1 booked.

-- ==========================================
-- 3. PL/SQL: Application Logic (Book a Tour)
-- ==========================================
SET SERVEROUTPUT ON;

CREATE OR REPLACE PROCEDURE Book_Tour(
    p_Tourist_ID INT,
    p_Package_ID INT
)
IS
    v_Max_Cap INT;
    v_Curr_Bookings INT;
    v_Cost DECIMAL(10, 2);
    v_Dest VARCHAR(50);
    v_Booking_ID INT;
BEGIN
    -- 1. Get package details (capacity, current bookings, cost, name)
    SELECT Max_Capacity, Current_Bookings, Cost, Destination
    INTO v_Max_Cap, v_Curr_Bookings, v_Cost, v_Dest
    FROM Tour_Package
    WHERE Package_ID = p_Package_ID;

    -- 2. Application Logic: Check if there is room on the tour
    IF v_Curr_Bookings < v_Max_Cap THEN
        
        -- Generate a new Booking ID
        SELECT NVL(MAX(Booking_ID), 5000) + 1 INTO v_Booking_ID FROM Booking;

        -- Create the booking record
        INSERT INTO Booking (Booking_ID, Tourist_ID, Package_ID)
        VALUES (v_Booking_ID, p_Tourist_ID, p_Package_ID);

        -- Update the package to reflect the new booking
        UPDATE Tour_Package
        SET Current_Bookings = Current_Bookings + 1
        WHERE Package_ID = p_Package_ID;

        COMMIT;
        DBMS_OUTPUT.PUT_LINE('SUCCESS: Booked ' || v_Dest || ' for Tourist ID ' || p_Tourist_ID || '. Total Cost: Rs. ' || v_Cost);
        
    ELSE
        -- The tour is full
        DBMS_OUTPUT.PUT_LINE('FAILED: Sorry, the package for ' || v_Dest || ' is fully booked (Capacity: ' || v_Max_Cap || ').');
    END IF;

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('ERROR: Invalid Tourist ID or Package ID.');
END;
/

