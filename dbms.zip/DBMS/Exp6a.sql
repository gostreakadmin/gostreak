--6   a) Create railway reservation database using DDL, DML commands and also display the train information using sub queries.

-- ==========================================
-- 1. DDL: Create Tables
-- ==========================================
CREATE TABLE Train_Master (
    Train_No INT PRIMARY KEY,
    Train_Name VARCHAR(50) NOT NULL,
    Source_Station VARCHAR(30),
    Dest_Station VARCHAR(30),
    Ticket_Price DECIMAL(10, 2)
);

CREATE TABLE Ticket_Booking (
    Ticket_ID INT PRIMARY KEY,
    Train_No INT,
    Passenger_Name VARCHAR(50),
    Seat_No VARCHAR(10),
    FOREIGN KEY (Train_No) REFERENCES Train_Master(Train_No)
);

-- ==========================================
-- 2. DML: Insert Records
-- ==========================================
-- Insert Train Details
INSERT INTO Train_Master VALUES (12671, 'Nilgiri Express', 'Chennai', 'Mettupalayam', 450.00);
INSERT INTO Train_Master VALUES (12673, 'Cheran Express', 'Chennai', 'Coimbatore', 550.00);
INSERT INTO Train_Master VALUES (16101, 'Kollam Express', 'Chennai', 'Kollam', 600.00);

-- Insert Ticket Bookings (Only for Nilgiri and Cheran Express)
INSERT INTO Ticket_Booking VALUES (501, 12671, 'Arun', 'S1-22');
INSERT INTO Ticket_Booking VALUES (502, 12673, 'Bala', 'A1-05');

COMMIT;

-- ==========================================
-- 3. DQL: Subquery to Display Train Info
-- ==========================================
-- Objective: Display details of trains that have at least one booking 
-- by using a subquery in the WHERE clause.

SELECT 
    Train_No, 
    Train_Name, 
    Source_Station, 
    Dest_Station 
FROM 
    Train_Master
WHERE 
    Train_No IN (SELECT DISTINCT Train_No FROM Ticket_Booking);