-- 8   a) Create a database for toy manufacturing company and display the products based on the cost using having clause.

-- ==========================================
-- 1. DDL: Create Table for Toy Company
-- ==========================================
CREATE TABLE Toy_Product (
    Toy_ID INT PRIMARY KEY,
    Toy_Name VARCHAR(50) NOT NULL,
    Category VARCHAR(50),
    Cost DECIMAL(10, 2) CHECK (Cost > 0)
);

-- ==========================================
-- 2. DML: Insert Toy Records
-- ==========================================
-- Electronics Category (High Cost)
INSERT INTO Toy_Product VALUES (1, 'RC Race Car', 'Electronics', 1500.00);
INSERT INTO Toy_Product VALUES (2, 'Quadcopter Drone', 'Electronics', 3500.00);

-- Soft Toys Category (Low Cost)
INSERT INTO Toy_Product VALUES (3, 'Giant Teddy Bear', 'Soft Toys', 400.00);
INSERT INTO Toy_Product VALUES (4, 'Plush Panda', 'Soft Toys', 300.00);

-- Building Blocks Category (Medium Cost)
INSERT INTO Toy_Product VALUES (5, 'Space Station Lego', 'Building Blocks', 1200.00);
INSERT INTO Toy_Product VALUES (6, 'Basic Bricks Set', 'Building Blocks', 600.00);

COMMIT;

-- ==========================================
-- 3. DQL: Display using the HAVING clause
-- ==========================================
-- Query Objective: Group the toys by category and display only those 
-- categories where the average cost of the products is greater than Rs. 500.

SELECT 
    Category, 
    COUNT(Toy_ID) AS Total_Products, 
    AVG(Cost) AS Average_Cost
FROM 
    Toy_Product
GROUP BY 
    Category
HAVING 
    AVG(Cost) > 500;