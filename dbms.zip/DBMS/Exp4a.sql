-- 4   a) Create a customer ,Saving_account toble in banking database by using DDl DML commands.

-- ==========================================
-- 1. DDL: Create Tables (Data Definition)
-- ==========================================

-- Table to store Customer personal information
CREATE TABLE Customer (
    Customer_ID INT PRIMARY KEY,
    Customer_Name VARCHAR(50) NOT NULL,
    City VARCHAR(30),
    Phone_No VARCHAR(15) UNIQUE
);

-- Table to store Savings Account information
CREATE TABLE Saving_Account (
    Account_No VARCHAR(15) PRIMARY KEY,
    Customer_ID INT,
    Account_Type VARCHAR(20) DEFAULT 'Savings',
    Balance DECIMAL(15, 2) CHECK (Balance >= 500), -- Minimum balance constraint
    Opening_Date DATE DEFAULT CURRENT_DATE,
    FOREIGN KEY (Customer_ID) REFERENCES Customer(Customer_ID)
);

-- ==========================================
-- 2. DML: Insert Records (Data Manipulation)
-- ==========================================

-- Inserting records into the Customer table
INSERT INTO Customer (Customer_ID, Customer_Name, City, Phone_No) 
VALUES (101, 'Rahul Verma', 'Mumbai', '9876543210');

INSERT INTO Customer (Customer_ID, Customer_Name, City, Phone_No) 
VALUES (102, 'Sonal Singh', 'Delhi', '9123456789');

-- Inserting records into the Saving_Account table
INSERT INTO Saving_Account (Account_No, Customer_ID, Balance) 
VALUES ('SB-001', 101, 15000.00);

INSERT INTO Saving_Account (Account_No, Customer_ID, Balance) 
VALUES ('SB-002', 102, 2500.50);

-- Save changes
COMMIT;

-- ==========================================
-- 3. Display Data
-- ==========================================
SELECT * FROM Customer;
SELECT * FROM Saving_Account;