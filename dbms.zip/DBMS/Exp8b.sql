-- 8   b) Write a procedure to insert and update the records in the above database.

-- Enable output display in the console
SET SERVEROUTPUT ON;

-- 1. Create the Procedure
CREATE OR REPLACE PROCEDURE Manage_Toy_Record(
    p_Toy_ID INT,
    p_Toy_Name VARCHAR,
    p_Category VARCHAR,
    p_Cost DECIMAL
)
IS
    v_record_exists INT;
BEGIN
    -- Check if the Toy_ID already exists in the table
    SELECT COUNT(*) INTO v_record_exists 
    FROM Toy_Product 
    WHERE Toy_ID = p_Toy_ID;

    IF v_record_exists > 0 THEN
        -- The record exists, so perform an UPDATE
        UPDATE Toy_Product
        SET Toy_Name = p_Toy_Name,
            Category = p_Category,
            Cost = p_Cost
        WHERE Toy_ID = p_Toy_ID;
        
        DBMS_OUTPUT.PUT_LINE('SUCCESS: Existing record UPDATED for Toy ID ' || p_Toy_ID);
    ELSE
        -- The record does not exist, so perform an INSERT
        INSERT INTO Toy_Product (Toy_ID, Toy_Name, Category, Cost)
        VALUES (p_Toy_ID, p_Toy_Name, p_Category, p_Cost);
        
        DBMS_OUTPUT.PUT_LINE('SUCCESS: New record INSERTED for Toy ID ' || p_Toy_ID);
    END IF;

    -- Save changes permanently
    COMMIT;

EXCEPTION
    WHEN OTHERS THEN
        -- Handle any unexpected errors (like violating a check constraint)
        DBMS_OUTPUT.PUT_LINE('ERROR: Failed to process record. Please check your inputs.');
        ROLLBACK;
END;
/

-- ==========================================
-- 2. Test Execution (What the examiner will see)
-- ==========================================

-- Test 1: INSERT a brand new toy (ID 10 does not exist yet)
-- BEGIN Manage_Toy_Record(10, 'Action Figure', 'Action Toys', 450.00); END;

-- Test 2: UPDATE an existing toy (Change the cost of the Action Figure we just added to 500.00)
-- BEGIN Manage_Toy_Record(10, 'Action Figure', 'Action Toys', 500.00); END;