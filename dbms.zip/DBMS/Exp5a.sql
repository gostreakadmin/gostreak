-- 5   a) Create a student table, subject_mark table, result table using DDL, DML commands and also compute the minimum, maximum, total, average marks in the above database.

-- DDL: Creating the Tables
CREATE TABLE Student_Info (
    Std_ID INT PRIMARY KEY,
    Std_Name VARCHAR(50)
);

CREATE TABLE Subject_Marks (
    Std_ID INT,
    Subject_1 INT,
    Subject_2 INT,
    Subject_3 INT,
    FOREIGN KEY (Std_ID) REFERENCES Student_Info(Std_ID)
);

CREATE TABLE Student_Result (
    Std_ID INT,
    Min_Mark INT,
    Max_Mark INT,
    Total_Marks INT,
    Average_Marks DECIMAL(5,2),
    Percentage DECIMAL(5,2),
    FOREIGN KEY (Std_ID) REFERENCES Student_Info(Std_ID)
);

-- DML: Inserting Data
INSERT INTO Student_Info VALUES (1, 'Alice');
INSERT INTO Student_Info VALUES (2, 'Bob');

INSERT INTO Subject_Marks VALUES (1, 85, 90, 88);
INSERT INTO Subject_Marks VALUES (2, 75, 60, 70);

-- DML: Computing and displaying min, max, total, and average marks using a query
SELECT 
    Std_ID,
    (Subject_1 + Subject_2 + Subject_3) AS Total_Marks,
    ROUND((Subject_1 + Subject_2 + Subject_3) / 3.0, 2) AS Average_Marks,
    LEAST(Subject_1, Subject_2, Subject_3) AS Min_Mark,
    GREATEST(Subject_1, Subject_2, Subject_3) AS Max_Mark
FROM Subject_Marks;