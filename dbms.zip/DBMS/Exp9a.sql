-- 9   a) Create and insert records in student table and course table and also display the records using different types of join operation.

-- ==========================================
-- 1. DDL: Create Course and Student Tables
-- ==========================================
CREATE TABLE Course_Tbl (
    Course_ID INT PRIMARY KEY,
    Course_Name VARCHAR(50)
);

CREATE TABLE Student_Tbl (
    Std_ID INT PRIMARY KEY,
    Std_Name VARCHAR(50),
    Course_ID INT,
    FOREIGN KEY (Course_ID) REFERENCES Course_Tbl(Course_ID)
);

-- ==========================================
-- 2. DML: Insert Records
-- ==========================================
-- Inserting Courses
INSERT INTO Course_Tbl VALUES (10, 'Computer Science');
INSERT INTO Course_Tbl VALUES (20, 'Mechanical Engg');
INSERT INTO Course_Tbl VALUES (30, 'Data Science'); -- No students will be in this course

-- Inserting Students
INSERT INTO Student_Tbl VALUES (1, 'Ramesh', 10);
INSERT INTO Student_Tbl VALUES (2, 'Suresh', 10);
INSERT INTO Student_Tbl VALUES (3, 'Anita', 20);
INSERT INTO Student_Tbl VALUES (4, 'Kavya', NULL); -- Student with no course assigned

COMMIT;

-- ==========================================
-- 3. DQL: Display Records Using Different Joins
-- ==========================================

-- A. INNER JOIN (Returns ONLY matches from both tables)
-- Result: Ramesh, Suresh, and Anita
SELECT s.Std_Name, c.Course_Name
FROM Student_Tbl s
INNER JOIN Course_Tbl c ON s.Course_ID = c.Course_ID;

-- B. LEFT JOIN (Returns ALL students, and their courses if matched)
-- Result: Everyone from Inner Join + Kavya (Course_Name will be NULL)
SELECT s.Std_Name, c.Course_Name
FROM Student_Tbl s
LEFT JOIN Course_Tbl c ON s.Course_ID = c.Course_ID;

-- C. RIGHT JOIN (Returns ALL courses, and enrolled students if matched)
-- Result: Everyone from Inner Join + Data Science (Std_Name will be NULL)
SELECT s.Std_Name, c.Course_Name
FROM Student_Tbl s
RIGHT JOIN Course_Tbl c ON s.Course_ID = c.Course_ID;

-- D. FULL OUTER JOIN (Returns EVERYTHING from both tables)
-- Result: Matches + Kavya (No Course) + Data Science (No Students)
SELECT s.Std_Name, c.Course_Name
FROM Student_Tbl s
FULL OUTER JOIN Course_Tbl c ON s.Course_ID = c.Course_ID;
