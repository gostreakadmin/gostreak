-- 10  b) Create XML database to conduct online quiz and declare the quiz results.

<?xml version="1.0" encoding="UTF-8"?>
<QuizDatabase>

    <Quizzes>
        <Quiz id="QZ_DBMS_01">
            <Subject>Database Management Systems</Subject>
            <PassingPercentage>50</PassingPercentage>
            
            <Question q_no="1">
                <QuestionText>Which SQL command is used to completely remove a table structure?</QuestionText>
                <Options>
                    <Option choice="A">DELETE</Option>
                    <Option choice="B">TRUNCATE</Option>
                    <Option choice="C">DROP</Option>
                    <Option choice="D">REMOVE</Option>
                </Options>
                <CorrectAnswer>C</CorrectAnswer>
            </Question>
            
            <Question q_no="2">
                <QuestionText>What does XML stand for?</QuestionText>
                <Options>
                    <Option choice="A">eXtensible Markup Language</Option>
                    <Option choice="B">eXtra Modern Link</Option>
                    <Option choice="C">Example Markup Language</Option>
                    <Option choice="D">X-Markup Language</Option>
                </Options>
                <CorrectAnswer>A</CorrectAnswer>
            </Question>
        </Quiz>
    </Quizzes>


    <QuizResults>
        
        <Result result_id="RES_1001">
            <Student_ID>STU_801</Student_ID>
            <Student_Name>Alice Smith</Student_Name>
            <Quiz_ID>QZ_DBMS_01</Quiz_ID>
            <DateTaken>2023-10-25</DateTaken>
            
            <AttemptDetails>
                <Response q_no="1" selected_choice="B" is_correct="false" />
                <Response q_no="2" selected_choice="A" is_correct="true" />
            </AttemptDetails>
            
            <FinalScore>
                <MarksObtained>1</MarksObtained>
                <TotalMarks>2</TotalMarks>
                <Percentage>50%</Percentage>
                <Status>Fail</Status>
            </FinalScore>
        </Result>

        <Result result_id="RES_1002">
            <Student_ID>STU_802</Student_ID>
            <Student_Name>Bob Jones</Student_Name>
            <Quiz_ID>QZ_DBMS_01</Quiz_ID>
            <DateTaken>2023-10-25</DateTaken>
            
            <AttemptDetails>
                <Response q_no="1" selected_choice="C" is_correct="true" />
                <Response q_no="2" selected_choice="A" is_correct="true" />
            </AttemptDetails>
            
            <FinalScore>
                <MarksObtained>2</MarksObtained>
                <TotalMarks>2</TotalMarks>
                <Percentage>100%</Percentage>
                <Status>Pass</Status>
            </FinalScore>
        </Result>

    </QuizResults>
    
</QuizDatabase>