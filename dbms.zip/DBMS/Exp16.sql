-- 16 Create software for society financial management.

-- ==========================================
-- 1. DDL: Create Tables for Society Finance
-- ==========================================
CREATE TABLE Society_Member (
    Member_ID INT PRIMARY KEY,
    Flat_Number VARCHAR(10) UNIQUE NOT NULL,
    Owner_Name VARCHAR(50) NOT NULL,
    Contact_Number VARCHAR(15)
);

CREATE TABLE Society_Fund (
    Fund_ID INT PRIMARY KEY,
    Fund_Name VARCHAR(50),
    Total_Balance DECIMAL(15, 2) DEFAULT 0.00
);

CREATE TABLE Maintenance_Bill (
    Bill_ID INT PRIMARY KEY,
    Member_ID INT,
    Bill_Month VARCHAR(20),
    Amount_Due DECIMAL(10, 2),
    Due_Date DATE,
    Status VARCHAR(20) DEFAULT 'Pending' CHECK (Status IN ('Pending', 'Paid', 'Overdue')),
    FOREIGN KEY (Member_ID) REFERENCES Society_Member(Member_ID)
);

CREATE TABLE Payment_Receipt (
    Receipt_ID INT PRIMARY KEY,
    Bill_ID INT,
    Payment_Date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    Amount_Paid DECIMAL(10, 2),
    Payment_Mode VARCHAR(20),
    FOREIGN KEY (Bill_ID) REFERENCES Maintenance_Bill(Bill_ID)
);

-- ==========================================
-- 2. DML: Insert Initial Data
-- ==========================================
-- Initialize the main society bank account/fund
INSERT INTO Society_Fund VALUES (1, 'General Maintenance Fund', 100000.00);

-- Add society members
INSERT INTO Society_Member VALUES (101, 'A-101', 'Rahul Sharma', '9876500001');
INSERT INTO Society_Member VALUES (102, 'B-205', 'Anita Desai', '9876500002');

-- Generate maintenance bills for the month of October
INSERT INTO Maintenance_Bill VALUES (5001, 101, 'October 2023', 2500.00, DATE '2023-10-10', 'Pending');
INSERT INTO Maintenance_Bill VALUES (5002, 102, 'October 2023', 3000.00, DATE '2023-10-10', 'Pending');

-- ==========================================
-- 3. PL/SQL: Application Logic (Process Payment)
-- ==========================================
SET SERVEROUTPUT ON;

CREATE OR REPLACE PROCEDURE Process_Maintenance_Payment(
    p_Bill_ID INT,
    p_Amount_Paid DECIMAL,
    p_Payment_Mode VARCHAR
)
IS
    v_Amount_Due DECIMAL(10, 2);
    v_Status VARCHAR(20);
    v_Flat VARCHAR(10);
    v_Receipt_ID INT;
BEGIN
    -- 1. Fetch bill details and the flat number
    SELECT m.Amount_Due, m.Status, s.Flat_Number 
    INTO v_Amount_Due, v_Status, v_Flat
    FROM Maintenance_Bill m
    JOIN Society_Member s ON m.Member_ID = s.Member_ID
    WHERE m.Bill_ID = p_Bill_ID;

    -- 2. Application Logic: Check if already paid
    IF v_Status = 'Paid' THEN
        DBMS_OUTPUT.PUT_LINE('NOTICE: Bill ' || p_Bill_ID || ' is already marked as Paid.');
        RETURN;
    END IF;

    -- 3. Check if the payment amount matches the due amount
    IF p_Amount_Paid >= v_Amount_Due THEN
        
        -- Generate a new Receipt ID
        SELECT NVL(MAX(Receipt_ID), 9000) + 1 INTO v_Receipt_ID FROM Payment_Receipt;

        -- Record the payment
        INSERT INTO Payment_Receipt (Receipt_ID, Bill_ID, Amount_Paid, Payment_Mode)
        VALUES (v_Receipt_ID, p_Bill_ID, p_Amount_Paid, p_Payment_Mode);

        -- Update the bill status to Paid
        UPDATE Maintenance_Bill 
        SET Status = 'Paid' 
        WHERE Bill_ID = p_Bill_ID;

        -- Add the money to the Society Fund
        UPDATE Society_Fund 
        SET Total_Balance = Total_Balance + p_Amount_Paid 
        WHERE Fund_ID = 1;

        COMMIT;
        DBMS_OUTPUT.PUT_LINE('SUCCESS: Payment of Rs. ' || p_Amount_Paid || ' received for Flat ' || v_Flat || '. Receipt ID: ' || v_Receipt_ID);
        
    ELSE
        DBMS_OUTPUT.PUT_LINE('FAILED: Insufficient amount. Rs. ' || v_Amount_Due || ' is required to clear this bill.');
    END IF;

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('ERROR: Invalid Bill ID.');
END;
/

