-- b) write a PL SQL programs to hike the employee salary, those who are all working under the production depertment by using where clause.

-- 1. DDL & DML: Setup the Employee Table
CREATE TABLE Employee (
    Emp_ID INT PRIMARY KEY,
    Emp_Name VARCHAR(50),
    Dept_Name VARCHAR(50),
    Salary DECIMAL(10, 2)
);

INSERT INTO Employee VALUES (1, 'Arjun', 'Production', 30000.00);
INSERT INTO Employee VALUES (2, 'Bala', 'Sales', 25000.00);
INSERT INTO Employee VALUES (3, 'Charlie', 'Production', 35000.00);
INSERT INTO Employee VALUES (4, 'Deepa', 'HR', 28000.00);
COMMIT;

-- 2. PL/SQL Program for Salary Hike
SET SERVEROUTPUT ON;

DECLARE
    v_dept_name VARCHAR(50) := 'Production';
    v_hike_percent NUMBER := 10; -- 10% hike
BEGIN
    -- Update salary only for those in the Production department
    UPDATE Employee
    SET Salary = Salary + (Salary * v_hike_percent / 100)
    WHERE Dept_Name = v_dept_name;

    -- Display the number of records affected
    IF SQL%FOUND THEN
        DBMS_OUTPUT.PUT_LINE('Success: Salary hiked for employees in ' || v_dept_name || ' department.');
        DBMS_OUTPUT.PUT_LINE('Total employees affected: ' || SQL%ROWCOUNT);
    ELSE
        DBMS_OUTPUT.PUT_LINE('No employees found in the ' || v_dept_name || ' department.');
    END IF;

    COMMIT;
END;
/

-- ==========================================
-- 3. Verification
-- ==========================================
-- SELECT * FROM Employee;