-- 7   a) Create an airline reservation database using DDL and DML commands and display the results after applying join operation to combine business class and economic class passenger.

-- ==========================================
-- 1. DDL: Create Tables
-- ==========================================
CREATE TABLE Flight_Details (
    Flight_No VARCHAR(10) PRIMARY KEY,
    Source VARCHAR(50),
    Destination VARCHAR(50),
    Departure_Time TIMESTAMP
);

CREATE TABLE Business_Class (
    P_ID INT PRIMARY KEY,
    P_Name VARCHAR(50),
    Seat_No VARCHAR(5),
    Flight_No VARCHAR(10),
    FOREIGN KEY (Flight_No) REFERENCES Flight_Details(Flight_No)
);

CREATE TABLE Economy_Class (
    P_ID INT PRIMARY KEY,
    P_Name VARCHAR(50),
    Seat_No VARCHAR(5),
    Flight_No VARCHAR(10),
    FOREIGN KEY (Flight_No) REFERENCES Flight_Details(Flight_No)
);

-- ==========================================
-- 2. DML: Insert Initial Data
-- ==========================================
INSERT INTO Flight_Details VALUES ('AI101', 'Chennai', 'Delhi', TIMESTAMP '2023-11-20 10:00:00');

-- Insert Business Class Passengers
INSERT INTO Business_Class VALUES (1001, 'Vikram', 'B1', 'AI101');
INSERT INTO Business_Class VALUES (1002, 'Srinath', 'B2', 'AI101');

-- Insert Economy Class Passengers
INSERT INTO Economy_Class VALUES (5001, 'Rahul', 'E15', 'AI101');
INSERT INTO Economy_Class VALUES (5002, 'Sneha', 'E22', 'AI101');

COMMIT;

-- ==========================================
-- 3. DQL: Join and Combine Results
-- ==========================================
-- This query joins the flight info with both tables and combines them 
-- into a single manifest using UNION ALL.

SELECT f.Flight_No, f.Source, f.Destination, p.P_Name, p.Seat_No, 'Business' AS Class
FROM Flight_Details f
JOIN Business_Class p ON f.Flight_No = p.Flight_No

UNION ALL

SELECT f.Flight_No, f.Source, f.Destination, e.P_Name, e.Seat_No, 'Economy' AS Class
FROM Flight_Details f
JOIN Economy_Class e ON f.Flight_No = e.Flight_No;