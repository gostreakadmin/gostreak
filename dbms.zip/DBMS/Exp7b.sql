-- 7   b) Write a procedure to avail reduction of flight fare while reserving tickets.


-- Enable output display in the console
SET SERVEROUTPUT ON;

-- 1. Create the Ticket Reservation Table
CREATE TABLE Flight_Booking (
    Booking_ID INT PRIMARY KEY,
    Passenger_Name VARCHAR(50),
    Flight_No VARCHAR(10),
    Original_Fare DECIMAL(10, 2),
    Final_Fare DECIMAL(10, 2),
    Status VARCHAR(20)
);

-- 2. Create the Procedure to Reserve with Discount
CREATE OR REPLACE PROCEDURE Reserve_Flight_Ticket(
    p_P_Name VARCHAR,
    p_Flight_No VARCHAR,
    p_Base_Fare DECIMAL,
    p_Discount_Code VARCHAR
)
IS
    v_Final_Fare DECIMAL(10, 2);
    v_Discount_Amount DECIMAL(10, 2) := 0;
    v_Booking_ID INT;
BEGIN
    -- Application Logic: Determine discount percentage based on code
    IF p_Discount_Code = 'SAVE10' THEN
        v_Discount_Amount := p_Base_Fare * 0.10; -- 10% reduction
    ELSIF p_Discount_Code = 'FESTIVE20' THEN
        v_Discount_Amount := p_Base_Fare * 0.20; -- 20% reduction
    ELSE
        v_Discount_Amount := 0; -- No reduction
    END IF;

    -- Calculate the final fare after reduction
    v_Final_Fare := p_Base_Fare - v_Discount_Amount;

    -- Generate a new Booking ID
    SELECT NVL(MAX(Booking_ID), 7000) + 1 INTO v_Booking_ID FROM Flight_Booking;

    -- Insert the reservation record
    INSERT INTO Flight_Booking (Booking_ID, Passenger_Name, Flight_No, Original_Fare, Final_Fare, Status)
    VALUES (v_Booking_ID, p_P_Name, p_Flight_No, p_Base_Fare, v_Final_Fare, 'Confirmed');

    COMMIT;

    -- Display the result to the user
    DBMS_OUTPUT.PUT_LINE('--- Ticket Reservation Details ---');
    DBMS_OUTPUT.PUT_LINE('Passenger: ' || p_P_Name);
    DBMS_OUTPUT.PUT_LINE('Original Fare: Rs. ' || p_Base_Fare);
    DBMS_OUTPUT.PUT_LINE('Discount Applied: Rs. ' || v_Discount_Amount);
    DBMS_OUTPUT.PUT_LINE('Final Fare to Pay: Rs. ' || v_Final_Fare);
    DBMS_OUTPUT.PUT_LINE('Booking ID: ' || v_Booking_ID);

EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('ERROR: Reservation failed. Please check inputs.');
        ROLLBACK;
END;
/

-- ==========================================
-- 3. Test Execution (What the examiner will see)
-- ==========================================

-- Test 1: Reserving with a 20% discount code
-- BEGIN Reserve_Flight_Ticket('Arjun', 'AI101', 5000.00, 'FESTIVE20'); END;

-- Test 2: Reserving without a valid discount code
-- BEGIN Reserve_Flight_Ticket('Meera', 'AI101', 5000.00, 'NONE'); END;