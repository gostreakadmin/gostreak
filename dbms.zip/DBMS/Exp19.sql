-- 19 Develop the application software for any retail business.

-- ==========================================
-- 1. DDL: Create Tables for Retail Business
-- ==========================================
CREATE TABLE Customer (
    Customer_ID INT PRIMARY KEY,
    Customer_Name VARCHAR(50) NOT NULL,
    Phone_Number VARCHAR(15),
    Loyalty_Points INT DEFAULT 0
);

CREATE TABLE Product (
    Product_ID INT PRIMARY KEY,
    Product_Name VARCHAR(50) NOT NULL,
    Category VARCHAR(30),
    Price DECIMAL(10, 2) CHECK (Price > 0),
    Stock_Quantity INT CHECK (Stock_Quantity >= 0)
);

CREATE TABLE Sales_Order (
    Order_ID INT PRIMARY KEY,
    Customer_ID INT,
    Order_Date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    Total_Amount DECIMAL(10, 2),
    FOREIGN KEY (Customer_ID) REFERENCES Customer(Customer_ID)
);

CREATE TABLE Order_Item (
    Order_ID INT,
    Product_ID INT,
    Quantity INT CHECK (Quantity > 0),
    Subtotal DECIMAL(10, 2),
    PRIMARY KEY (Order_ID, Product_ID),
    FOREIGN KEY (Order_ID) REFERENCES Sales_Order(Order_ID),
    FOREIGN KEY (Product_ID) REFERENCES Product(Product_ID)
);

-- ==========================================
-- 2. DML: Insert Initial Inventory and Customers
-- ==========================================
INSERT INTO Customer (Customer_ID, Customer_Name, Phone_Number) VALUES (201, 'David Smith', '555-0101');
INSERT INTO Customer (Customer_ID, Customer_Name, Phone_Number) VALUES (202, 'Emma Watson', '555-0202');

INSERT INTO Product VALUES (10, 'Wireless Mouse', 'Electronics', 25.00, 100);
INSERT INTO Product VALUES (11, 'Mechanical Keyboard', 'Electronics', 85.00, 50);
INSERT INTO Product VALUES (12, 'Desk Lamp', 'Home Goods', 30.00, 20);

-- ==========================================
-- 3. PL/SQL: Application Logic (Process a Sale)
-- ==========================================
SET SERVEROUTPUT ON;

CREATE OR REPLACE PROCEDURE Process_Retail_Sale(
    p_Customer_ID INT,
    p_Product_ID INT,
    p_Quantity INT
) 
IS
    v_Stock INT;
    v_Price DECIMAL(10, 2);
    v_Total DECIMAL(10, 2);
    v_Order_ID INT;
    v_Points_Earned INT;
BEGIN
    -- 1. Check current stock and get product price
    SELECT Stock_Quantity, Price INTO v_Stock, v_Price 
    FROM Product WHERE Product_ID = p_Product_ID;

    -- 2. Application Logic: Ensure enough stock exists
    IF v_Stock >= p_Quantity THEN
        v_Total := v_Price * p_Quantity;
        
        -- Calculate loyalty points (1 point for every $10 spent)
        v_Points_Earned := FLOOR(v_Total / 10);

        -- Generate a new Order ID
        SELECT NVL(MAX(Order_ID), 1000) + 1 INTO v_Order_ID FROM Sales_Order;

        -- 3. Record the Sale
        INSERT INTO Sales_Order (Order_ID, Customer_ID, Total_Amount) 
        VALUES (v_Order_ID, p_Customer_ID, v_Total);

        INSERT INTO Order_Item (Order_ID, Product_ID, Quantity, Subtotal)
        VALUES (v_Order_ID, p_Product_ID, p_Quantity, v_Total);

        -- 4. Update the Product Stock
        UPDATE Product 
        SET Stock_Quantity = Stock_Quantity - p_Quantity 
        WHERE Product_ID = p_Product_ID;

        -- 5. Update Customer Loyalty Points
        UPDATE Customer 
        SET Loyalty_Points = Loyalty_Points + v_Points_Earned 
        WHERE Customer_ID = p_Customer_ID;

        COMMIT;
        DBMS_OUTPUT.PUT_LINE('SUCCESS: Order ' || v_Order_ID || ' processed. Total: $' || v_Total || '. Points Earned: ' || v_Points_Earned);
    ELSE
        DBMS_OUTPUT.PUT_LINE('FAILED: Insufficient stock. Only ' || v_Stock || ' units available.');
    END IF;

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('ERROR: Invalid Customer ID or Product ID.');
END;
/

-- To test the retail application logic:
-- BEGIN Process_Retail_Sale(201, 11, 2); END; 
-- (This will sell 2 Mechanical Keyboards to David Smith)