-- 11. b) Create Document, column and graph based data using NOSQL database tools.


/* =====================================================================
   1. DOCUMENT-BASED DATA (Tools: MongoDB / JavaScript)
   Logic: Uses JSON-like structures to store hierarchical data.
   ===================================================================== */

// Command to insert a student document with nested arrays and objects
db.students.insertOne({
    "student_id": "STU_101",
    "name": "Arjun Kumar",
    "academic_info": {
        "batch": 2024,
        "major": "Computer Science"
    },
    "subjects": ["DBMS", "NoSQL", "OS"],
    "status": "Active"
});


/* =====================================================================
   2. COLUMN-FAMILY DATA (Tools: Apache Cassandra / CQL)
   Logic: Optimized for large-scale data stored in rows and dynamic columns.
   ===================================================================== */

-- Create the table structure
CREATE TABLE user_activity (
    user_id UUID PRIMARY KEY,
    username text,
    login_time timestamp,
    ip_address text
);

-- Insert data into the column family
INSERT INTO user_activity (user_id, username, login_time, ip_address)
VALUES (uuid(), 'user_alpha', toTimestamp(now()), '192.168.1.1');


/* =====================================================================
   3. GRAPH-BASED DATA (Tools: Neo4j / Cypher)
   Logic: Stores data as Nodes (Entities) and Edges (Relationships).
   ===================================================================== */

// Create a student node, a course node, and the relationship between them
CREATE (s:Student {name: 'Priya', roll_no: 501})
CREATE (c:Course {name: 'Data Science', code: 'DS01'})
CREATE (s)-[:ENROLLED_IN {date: '2023-10-01'}]->(c);

// Query to retrieve the graph data
MATCH (s:Student)-[r:ENROLLED_IN]->(c:Course)
RETURN s, r, c;