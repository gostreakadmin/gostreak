-- 6   b) Write PL SQL Triggers to display available seats after a successful reservation and also display the available seats before reservation.

-- 1. DDL: Create the necessary tables
CREATE TABLE Train_Seats (
    Train_ID INT PRIMARY KEY,
    Train_Name VARCHAR(50),
    Available_Seats INT CHECK (Available_Seats >= 0)
);

CREATE TABLE Train_Reservation (
    Res_ID INT PRIMARY KEY,
    Train_ID INT,
    Passenger_Name VARCHAR(50),
    Seats_Booked INT,
    FOREIGN KEY (Train_ID) REFERENCES Train_Seats(Train_ID)
);

-- 2. DML: Initialize a train with 100 seats
INSERT INTO Train_Seats VALUES (101, 'Grand Trunk Express', 100);
COMMIT;

-- 3. PL/SQL Trigger: Seat Display and Update
SET SERVEROUTPUT ON;

CREATE OR REPLACE TRIGGER TRG_Display_Seats
BEFORE INSERT ON Train_Reservation
FOR EACH ROW
DECLARE
    v_seats_before INT;
    v_seats_after INT;
BEGIN
    -- Step 1: Get available seats BEFORE reservation
    SELECT Available_Seats INTO v_seats_before 
    FROM Train_Seats 
    WHERE Train_ID = :NEW.Train_ID;

    DBMS_OUTPUT.PUT_LINE('--- Seat Availability Update ---');
    DBMS_OUTPUT.PUT_LINE('Seats available BEFORE reservation: ' || v_seats_before);

    -- Step 2: Check if enough seats are available
    IF v_seats_before >= :NEW.Seats_Booked THEN
        
        -- Update the seat count in the Master table
        UPDATE Train_Seats
        SET Available_Seats = Available_Seats - :NEW.Seats_Booked
        WHERE Train_ID = :NEW.Train_ID;

        -- Step 3: Get available seats AFTER reservation
        SELECT Available_Seats INTO v_seats_after 
        FROM Train_Seats 
        WHERE Train_ID = :NEW.Train_ID;

        DBMS_OUTPUT.PUT_LINE('Booking Successful for ' || :NEW.Passenger_Name);
        DBMS_OUTPUT.PUT_LINE('Seats available AFTER reservation: ' || v_seats_after);
        
    ELSE
        -- Raise an error if seats are not enough
        RAISE_APPLICATION_ERROR(-20001, 'Insufficient seats available for this booking.');
    END IF;
END;
/

-- ==========================================
-- 4. Test Execution (Run this to see the trigger in action)
-- ==========================================

-- This insert will trigger the DBMS_OUTPUT messages
-- INSERT INTO Train_Reservation VALUES (1, 101, 'John Doe', 5);