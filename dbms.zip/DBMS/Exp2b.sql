-- 2   b) write a PL SQL trigger for inserting, deleting operations in a student datebase table.

-- 1. DDL: Create an Audit Table to track changes
CREATE TABLE Student_Audit_Log (
    Log_ID INT PRIMARY KEY,
    Action_Type VARCHAR(20),
    Roll_No INT,
    Action_Date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. PL/SQL Trigger Code
SET SERVEROUTPUT ON;

CREATE OR REPLACE TRIGGER TRG_Student_Audit
AFTER INSERT OR DELETE ON Student
FOR EACH ROW
DECLARE
    v_Log_ID INT;
BEGIN
    -- Generate a unique ID for the log entry
    SELECT NVL(MAX(Log_ID), 0) + 1 INTO v_Log_ID FROM Student_Audit_Log;

    -- Check which operation is being performed
    IF INSERTING THEN
        INSERT INTO Student_Audit_Log (Log_ID, Action_Type, Roll_No)
        VALUES (v_Log_ID, 'INSERT', :NEW.Roll_No);
        DBMS_OUTPUT.PUT_LINE('AUDIT: New student record added. Roll No: ' || :NEW.Roll_No);

    ELSIF DELETING THEN
        INSERT INTO Student_Audit_Log (Log_ID, Action_Type, Roll_No)
        VALUES (v_Log_ID, 'DELETE', :OLD.Roll_No);
        DBMS_OUTPUT.PUT_LINE('AUDIT: Student record removed. Roll No: ' || :OLD.Roll_No);
    END IF;
END;
/

-- ==========================================
-- 3. Test Execution (Demonstration)
-- ==========================================

-- Test 1: Insert a student (Fires the INSERTING block)
-- INSERT INTO Student VALUES (105, 'Meher', 'F', 10);

-- Test 2: Delete a student (Fires the DELETING block)
-- DELETE FROM Student WHERE Roll_No = 101;

-- Check the Audit Log to see the results
-- SELECT * FROM Student_Audit_Log;