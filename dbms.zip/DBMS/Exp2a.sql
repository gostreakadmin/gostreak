-- 2   a) Create a set of tables for student database, add foreign key constraints and incorporate referential integrity.

-- ==========================================
-- 1. DDL: Create Tables with Constraints
-- ==========================================

-- Parent Table: Must be created first
CREATE TABLE Department (
    Dept_ID INT PRIMARY KEY,
    Dept_Name VARCHAR(50) NOT NULL,
    HOD_Name VARCHAR(50)
);

-- Child Table: Contains the Foreign Key
CREATE TABLE Student (
    Roll_No INT PRIMARY KEY,
    Student_Name VARCHAR(50) NOT NULL,
    Gender CHAR(1) CHECK (Gender IN ('M', 'F')),
    Dept_ID INT,
    -- Incorporating Referential Integrity
    CONSTRAINT fk_dept 
        FOREIGN KEY (Dept_ID) 
        REFERENCES Department(Dept_ID)
        ON DELETE CASCADE -- If a Dept is deleted, its students are removed
);

-- ==========================================
-- 2. DML: Insert Data (Ordering Matters)
-- ==========================================

-- First, insert into the Parent Table
INSERT INTO Department VALUES (10, 'Computer Science', 'Dr. Aruna');
INSERT INTO Department VALUES (20, 'Information Tech', 'Dr. Bhaskar');

-- Second, insert into the Child Table
INSERT INTO Student VALUES (101, 'Aditya', 'M', 10);
INSERT INTO Student VALUES (102, 'Bhavna', 'F', 10);
INSERT INTO Student VALUES (103, 'Chitra', 'F', 20);

COMMIT;

-- ==========================================
-- 3. Testing Referential Integrity
-- ==========================================

-- This will FAIL because Dept_ID 99 does not exist in the Department table
-- INSERT INTO Student VALUES (104, 'Invalid User', 'M', 99);

-- Display the combined results
SELECT s.Roll_No, s.Student_Name, d.Dept_Name
FROM Student s
JOIN Department d ON s.Dept_ID = d.Dept_ID;