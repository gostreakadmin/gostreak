-- 9   b) Write a procedure to display month's name while passing the month as number parameter. (Example: if pass parameter as 1 it should display as January.)

-- Enable output display in the console
SET SERVEROUTPUT ON;

-- 1. Create the Procedure
CREATE OR REPLACE PROCEDURE Display_Month_Name(
    p_month_no INT
)
IS
    v_month_name VARCHAR(20);
BEGIN
    -- Evaluate the input number using a CASE statement
    CASE p_month_no
        WHEN 1  THEN v_month_name := 'January';
        WHEN 2  THEN v_month_name := 'February';
        WHEN 3  THEN v_month_name := 'March';
        WHEN 4  THEN v_month_name := 'April';
        WHEN 5  THEN v_month_name := 'May';
        WHEN 6  THEN v_month_name := 'June';
        WHEN 7  THEN v_month_name := 'July';
        WHEN 8  THEN v_month_name := 'August';
        WHEN 9  THEN v_month_name := 'September';
        WHEN 10 THEN v_month_name := 'October';
        WHEN 11 THEN v_month_name := 'November';
        WHEN 12 THEN v_month_name := 'December';
        ELSE v_month_name := 'Invalid';
    END CASE;

    -- Display the result
    IF v_month_name = 'Invalid' THEN
        DBMS_OUTPUT.PUT_LINE('ERROR: Please pass a valid month number between 1 and 12.');
    ELSE
        DBMS_OUTPUT.PUT_LINE('Input: ' || p_month_no || ' -> The month is ' || v_month_name || '.');
    END IF;
    
END;
/

-- ==========================================
-- 2. Test Execution (What the examiner will see)
-- ==========================================

-- Test 1: Passing '1' (Should print January)
-- BEGIN Display_Month_Name(1); END;

-- Test 2: Passing '8' (Should print August)
-- BEGIN Display_Month_Name(8); END;

-- Test 3: Passing an invalid number (Should print Error)
-- BEGIN Display_Month_Name(15); END;