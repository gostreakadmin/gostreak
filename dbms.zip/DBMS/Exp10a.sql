-- 10  a) Write a DCL command to allow the user to create, insert, update and delete operation and also disallow the particular user to perform delete operation.

-- 1. Granting permissions to allow CREATE, INSERT, UPDATE, and DELETE
-- Note: In many database systems like Oracle, CREATE is a system privilege, 
-- while INSERT, UPDATE, and DELETE are object (table) privileges.

-- Granting the ability to create tables in the database
GRANT CREATE TABLE TO exam_user;

-- Granting data manipulation permissions on a specific table
GRANT INSERT, UPDATE, DELETE ON Employee_Data TO exam_user;


-- 2. Disallowing (revoking) ONLY the delete operation from that particular user
REVOKE DELETE ON Employee_Data FROM exam_user;
