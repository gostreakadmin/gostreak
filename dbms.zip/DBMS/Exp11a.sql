-- 11  a) Write and execute complex transaction in a larger database and also realize TCL commands.

-- ==========================================
-- 1. Setup Banking Database Environment
-- ==========================================
CREATE TABLE Bank_Account (
    Account_No INT PRIMARY KEY,
    Customer_Name VARCHAR(50),
    Balance DECIMAL(15, 2) CHECK (Balance >= 0)
);

CREATE TABLE Transaction_Log (
    Log_ID INT PRIMARY KEY,
    From_Account INT,
    To_Account INT,
    Transfer_Amount DECIMAL(15, 2),
    Log_Time TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO Bank_Account VALUES (101, 'Alice', 50000.00);
INSERT INTO Bank_Account VALUES (102, 'Bob', 20000.00);
INSERT INTO Bank_Account VALUES (103, 'Charlie', 10000.00);

-- Save the initial setup state
COMMIT;

-- ==========================================
-- 2. PL/SQL Complex Transaction (Fund Transfer)
-- ==========================================
SET SERVEROUTPUT ON;

DECLARE
    v_Sender_Acc INT := 101;
    v_Receiver_Acc INT := 102;
    v_Transfer_Amount DECIMAL(15, 2) := 15000.00;
    v_Sender_Balance DECIMAL(15, 2);
BEGIN
    DBMS_OUTPUT.PUT_LINE('--- Starting Fund Transfer Transaction ---');

    -- Step 1: Check balance and lock the row for update
    SELECT Balance INTO v_Sender_Balance FROM Bank_Account WHERE Account_No = v_Sender_Acc FOR UPDATE;

    IF v_Sender_Balance >= v_Transfer_Amount THEN
        
        -- Step 2: Deduct from Sender
        UPDATE Bank_Account SET Balance = Balance - v_Transfer_Amount WHERE Account_No = v_Sender_Acc;
        
        -- TCL: Savepoint created in case later steps fail
        SAVEPOINT after_deduction;
        DBMS_OUTPUT.PUT_LINE('Money deducted from Sender. Savepoint created.');

        -- Step 3: Add to Receiver
        UPDATE Bank_Account SET Balance = Balance + v_Transfer_Amount WHERE Account_No = v_Receiver_Acc;
        DBMS_OUTPUT.PUT_LINE('Money added to Receiver.');

        -- Step 4: Audit Log
        INSERT INTO Transaction_Log (Log_ID, From_Account, To_Account, Transfer_Amount)
        VALUES (1, v_Sender_Acc, v_Receiver_Acc, v_Transfer_Amount);

        -- TCL: Make changes permanent
        COMMIT;
        DBMS_OUTPUT.PUT_LINE('SUCCESS: Transaction Completed and Committed to Database.');

    ELSE
        DBMS_OUTPUT.PUT_LINE('FAILED: Insufficient Funds.');
    END IF;

EXCEPTION
    WHEN OTHERS THEN
        -- TCL: Undo everything if an error occurs
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('CRITICAL ERROR: Transaction Failed. All changes have been ROLLED BACK.');
END;
/