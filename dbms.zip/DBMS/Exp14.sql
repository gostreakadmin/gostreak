-- 14 Develop an application for small finance corporation.

-- ==========================================
-- 1. DDL: Create Tables for Finance System
-- ==========================================
CREATE TABLE Client (
    Client_ID INT PRIMARY KEY,
    Client_Name VARCHAR(50) NOT NULL,
    Contact_No VARCHAR(15) UNIQUE,
    KYC_Status VARCHAR(20) DEFAULT 'Verified'
);

CREATE TABLE Loan_Account (
    Loan_ID INT PRIMARY KEY,
    Client_ID INT,
    Loan_Amount DECIMAL(12, 2) CHECK (Loan_Amount > 0),
    Interest_Rate DECIMAL(5, 2),
    Amount_Paid DECIMAL(12, 2) DEFAULT 0.00,
    Status VARCHAR(20) DEFAULT 'Active' CHECK (Status IN ('Active', 'Closed', 'Defaulted')),
    FOREIGN KEY (Client_ID) REFERENCES Client(Client_ID)
);

CREATE TABLE Loan_Repayment (
    Repayment_ID INT PRIMARY KEY,
    Loan_ID INT,
    Payment_Date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    Amount DECIMAL(12, 2) CHECK (Amount > 0),
    FOREIGN KEY (Loan_ID) REFERENCES Loan_Account(Loan_ID)
);

-- ==========================================
-- 2. DML: Insert Initial Data
-- ==========================================
-- Register Clients
INSERT INTO Client (Client_ID, Client_Name, Contact_No) VALUES (401, 'Ravi Verma', '9876511111');
INSERT INTO Client (Client_ID, Client_Name, Contact_No) VALUES (402, 'Sita Ram', '9876522222');

-- Disburse Loans to Clients
-- Ravi takes a 50k loan, hasn't paid anything yet
INSERT INTO Loan_Account VALUES (10001, 401, 50000.00, 12.00, 0.00, 'Active');

-- Sita took a 1 Lakh loan and has already paid back 95k
INSERT INTO Loan_Account VALUES (10002, 402, 100000.00, 10.50, 95000.00, 'Active');

-- ==========================================
-- 3. PL/SQL: Application Logic (Process Repayment)
-- ==========================================
SET SERVEROUTPUT ON;

CREATE OR REPLACE PROCEDURE Process_Loan_Repayment(
    p_Loan_ID INT,
    p_Payment_Amount DECIMAL
)
IS
    v_Principal DECIMAL(12, 2);
    v_Paid DECIMAL(12, 2);
    v_Remaining DECIMAL(12, 2);
    v_Repayment_ID INT;
BEGIN
    -- 1. Get current loan details
    SELECT Loan_Amount, Amount_Paid
    INTO v_Principal, v_Paid
    FROM Loan_Account
    WHERE Loan_ID = p_Loan_ID AND Status = 'Active';

    v_Remaining := v_Principal - v_Paid;

    -- 2. Application Logic: Validate the payment amount
    IF p_Payment_Amount <= v_Remaining THEN
        
        -- Generate a new Repayment ID safely
        SELECT NVL(MAX(Repayment_ID), 50000) + 1 INTO v_Repayment_ID FROM Loan_Repayment;

        -- Record the transaction
        INSERT INTO Loan_Repayment (Repayment_ID, Loan_ID, Amount)
        VALUES (v_Repayment_ID, p_Loan_ID, p_Payment_Amount);

        -- Update the total amount paid on the loan
        UPDATE Loan_Account
        SET Amount_Paid = Amount_Paid + p_Payment_Amount
        WHERE Loan_ID = p_Loan_ID;

        -- 3. Check if the loan is fully paid off
        IF (v_Paid + p_Payment_Amount) >= v_Principal THEN
            -- Close the loan account
            UPDATE Loan_Account SET Status = 'Closed' WHERE Loan_ID = p_Loan_ID;
            DBMS_OUTPUT.PUT_LINE('SUCCESS: Payment of Rs. ' || p_Payment_Amount || ' received. Loan ' || p_Loan_ID || ' is now FULLY CLOSED.');
        ELSE
            -- Show remaining balance
            DBMS_OUTPUT.PUT_LINE('SUCCESS: Payment of Rs. ' || p_Payment_Amount || ' received. Remaining balance: Rs. ' || (v_Principal - (v_Paid + p_Payment_Amount)));
        END IF;

        COMMIT;
        
    ELSE
        -- Payment exceeds what is actually owed
        DBMS_OUTPUT.PUT_LINE('FAILED: Payment exceeds remaining balance. The maximum remaining amount to pay is Rs. ' || v_Remaining);
    END IF;

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('ERROR: Invalid Loan ID or the Loan Account is already closed.');
END;
/

