-- 3   a) write a  query to display all books details related to "Database Management Systems" by using where clause.

-- ==========================================
-- 1. DDL: Create Library Table
-- ==========================================
CREATE TABLE Books (
    Book_ID INT PRIMARY KEY,
    Title VARCHAR(100) NOT NULL,
    Author VARCHAR(50),
    Subject VARCHAR(50),
    Price DECIMAL(10, 2),
    Published_Year INT
);

-- ==========================================
-- 2. DML: Insert Sample Records
-- ==========================================
INSERT INTO Books VALUES (1, 'Fundamentals of Database Systems', 'Navathe', 'Database Management Systems', 750.00, 2021);
INSERT INTO Books VALUES (2, 'Core Java', 'Cay Horstmann', 'Programming', 600.00, 2019);
INSERT INTO Books VALUES (3, 'Database System Concepts', 'Korth', 'Database Management Systems', 850.00, 2020);
INSERT INTO Books VALUES (4, 'Modern Operating Systems', 'Tanenbaum', 'Operating Systems', 900.00, 2018);
INSERT INTO Books VALUES (5, 'SQL Queries for Mere Mortals', 'Viescas', 'Database Management Systems', 450.00, 2022);

COMMIT;

-- ==========================================
-- 3. DQL: Query using WHERE Clause
-- ==========================================
-- Objective: Retrieve all details for books where the subject 
-- is exactly "Database Management Systems".

SELECT * FROM Books 
WHERE Subject = 'Database Management Systems';