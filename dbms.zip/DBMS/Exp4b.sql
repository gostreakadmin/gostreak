-- 4   b) write a procedure to insert 50 records for each table in above banking database.

-- Enable console output
SET SERVEROUTPUT ON;

CREATE OR REPLACE PROCEDURE Bulk_Insert_Banking_Data
IS
    v_base_phone NUMBER := 9000000000;
BEGIN
    -- 1. Insert 50 Records into the Customer Table
    FOR i IN 1..50 LOOP
        INSERT INTO Customer (Customer_ID, Customer_Name, City, Phone_No)
        VALUES (
            1000 + i,              -- Customer ID: 1001, 1002...
            'Customer_' || i,      -- Name: Customer_1, Customer_2...
            'City_' || i,          -- City: City_1, City_2...
            TO_CHAR(v_base_phone + i) -- Unique Phone Number
        );
    END LOOP;
    
    DBMS_OUTPUT.PUT_LINE('Successfully inserted 50 records into Customer table.');

    -- 2. Insert 50 Records into the Saving_Account Table
    -- Note: Every account must link to a Customer_ID we just created.
    FOR j IN 1..50 LOOP
        INSERT INTO Saving_Account (Account_No, Customer_ID, Balance, Opening_Date)
        VALUES (
            'ACC-ST-' || (5000 + j), -- Account No: ACC-ST-5001, 5002...
            1000 + j,                -- Links to the Customer_IDs created above
            5000 + (j * 100),        -- Incremental Balance for testing
            CURRENT_DATE
        );
    END LOOP;

    DBMS_OUTPUT.PUT_LINE('Successfully inserted 50 records into Saving_Account table.');

    -- Commit all 100 insertions at once
    COMMIT;
    
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('An error occurred during bulk insertion. Rolling back.');
        ROLLBACK;
END;
/

-- ==========================================
-- Execution
-- ==========================================
-- To run the procedure and insert the data:
-- BEGIN Bulk_Insert_Banking_Data; END;

-- To verify the data:
-- SELECT COUNT(*) FROM Customer;
-- SELECT COUNT(*) FROM Saving_Account;