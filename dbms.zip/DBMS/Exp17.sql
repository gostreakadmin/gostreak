-- 17 Create software for property management in eMall.

-- ==========================================
-- 1. DDL: Create Tables for eMall Property Management
-- ==========================================
CREATE TABLE Shop_Unit (
    Shop_ID INT PRIMARY KEY,
    Unit_Number VARCHAR(20) UNIQUE NOT NULL,
    Floor_Level INT,
    Area_SqFt INT,
    Status VARCHAR(20) DEFAULT 'Available' CHECK (Status IN ('Available', 'Occupied', 'Maintenance'))
);

CREATE TABLE Tenant (
    Tenant_ID INT PRIMARY KEY,
    Business_Name VARCHAR(100) NOT NULL,
    Contact_Person VARCHAR(50),
    Phone_Number VARCHAR(15)
);

CREATE TABLE Lease_Agreement (
    Lease_ID INT PRIMARY KEY,
    Shop_ID INT,
    Tenant_ID INT,
    Start_Date DATE,
    Monthly_Rent DECIMAL(10, 2),
    FOREIGN KEY (Shop_ID) REFERENCES Shop_Unit(Shop_ID),
    FOREIGN KEY (Tenant_ID) REFERENCES Tenant(Tenant_ID)
);

CREATE TABLE Rent_Payment (
    Payment_ID INT PRIMARY KEY,
    Lease_ID INT,
    Payment_Date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    Amount_Paid DECIMAL(10, 2),
    FOREIGN KEY (Lease_ID) REFERENCES Lease_Agreement(Lease_ID)
);

-- ==========================================
-- 2. DML: Insert Initial Mall Data
-- ==========================================
-- Add some shop units
INSERT INTO Shop_Unit VALUES (101, 'G-01', 0, 1500, 'Occupied');
INSERT INTO Shop_Unit VALUES (102, 'G-02', 0, 800, 'Available');
INSERT INTO Shop_Unit VALUES (201, 'F1-05', 1, 1200, 'Occupied');

-- Add tenants
INSERT INTO Tenant VALUES (5001, 'TechWorld Electronics', 'John Doe', '555-1010');
INSERT INTO Tenant VALUES (5002, 'Brew & Bean Coffee', 'Jane Smith', '555-2020');

-- Create active lease agreements for the occupied shops
-- (Using ANSI standard date format for broad compatibility)
INSERT INTO Lease_Agreement VALUES (1, 101, 5001, DATE '2023-01-01', 5000.00);
INSERT INTO Lease_Agreement VALUES (2, 201, 5002, DATE '2023-06-15', 3500.00);

-- ==========================================
-- 3. PL/SQL: Application Logic (Process Rent Payment)
-- ==========================================
SET SERVEROUTPUT ON;

CREATE OR REPLACE PROCEDURE Process_Rent_Payment(
    p_Lease_ID INT,
    p_Amount_Paid DECIMAL
)
IS
    v_Expected_Rent DECIMAL(10, 2);
    v_Payment_ID INT;
    v_Business_Name VARCHAR(100);
BEGIN
    -- 1. Fetch expected rent and tenant details
    SELECT l.Monthly_Rent, t.Business_Name 
    INTO v_Expected_Rent, v_Business_Name
    FROM Lease_Agreement l
    JOIN Tenant t ON l.Tenant_ID = t.Tenant_ID
    WHERE l.Lease_ID = p_Lease_ID;

    -- 2. Generate new Payment ID securely
    SELECT NVL(MAX(Payment_ID), 1000) + 1 INTO v_Payment_ID FROM Rent_Payment;

    -- 3. Record the Payment
    INSERT INTO Rent_Payment (Payment_ID, Lease_ID, Amount_Paid)
    VALUES (v_Payment_ID, p_Lease_ID, p_Amount_Paid);

    -- 4. Application Logic: Check if payment covers the rent
    IF p_Amount_Paid >= v_Expected_Rent THEN
        DBMS_OUTPUT.PUT_LINE('SUCCESS: Rent fully paid for ' || v_Business_Name || '. Amount: $' || p_Amount_Paid);
    ELSE
        DBMS_OUTPUT.PUT_LINE('WARNING: Partial rent paid for ' || v_Business_Name || '. Expected: $' || v_Expected_Rent || ', Paid: $' || p_Amount_Paid || '. Pending Due: $' || (v_Expected_Rent - p_Amount_Paid));
    END IF;

    COMMIT;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('ERROR: Invalid Lease ID. Payment aborted.');
END;
/

