-- b) Write a user defined function to update and release the student's result with percentage.

-- PL/SQL: User Defined Function
CREATE OR REPLACE FUNCTION Generate_Result(p_Std_ID INT) 
RETURN VARCHAR IS
    v_sub1 INT; v_sub2 INT; v_sub3 INT;
    v_total INT; v_avg DECIMAL(5,2); v_min INT; v_max INT; v_percent DECIMAL(5,2);
BEGIN
    -- Fetch the marks for the specific student
    SELECT Subject_1, Subject_2, Subject_3 
    INTO v_sub1, v_sub2, v_sub3 
    FROM Subject_Marks WHERE Std_ID = p_Std_ID;
    
    -- Calculate values
    v_total := v_sub1 + v_sub2 + v_sub3;
    v_avg := v_total / 3.0;
    v_percent := (v_total / 300.0) * 100;
    
    -- Oracle specific LEAST/GREATEST for variables
    SELECT LEAST(v_sub1, v_sub2, v_sub3), GREATEST(v_sub1, v_sub2, v_sub3) 
    INTO v_min, v_max FROM dual;

    -- Update/Insert into Result table
    INSERT INTO Student_Result (Std_ID, Min_Mark, Max_Mark, Total_Marks, Average_Marks, Percentage)
    VALUES (p_Std_ID, v_min, v_max, v_total, v_avg, v_percent);
    
    COMMIT;
    RETURN 'Result successfully released for Student ID: ' || p_Std_ID || ' with ' || v_percent || '%';
END;
/

-- To execute the function:
-- DECLARE result_msg VARCHAR(100);
-- BEGIN result_msg := Generate_Result(1); DBMS_OUTPUT.PUT_LINE(result_msg); END;