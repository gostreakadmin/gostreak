--1.  a)  Create an employee database table, add constraints(primary key, Unique, check, Not null), insert rows, Update and delete rows using SQL DDL and DML Commands.

-- 1. Create table with constraints (Primary Key, Not Null, Unique, Check)
CREATE TABLE Employee (
    EmpID INT PRIMARY KEY,
    EmpName VARCHAR(50) NOT NULL,
    Email VARCHAR(100) UNIQUE,
    Salary DECIMAL(10, 2) CHECK (Salary > 0),
    Department VARCHAR(50)
);

-- 2. Insert rows
INSERT INTO Employee (EmpID, EmpName, Email, Salary, Department)
VALUES 
    (101, 'John Doe', 'john.doe@email.com', 55000.00, 'IT'),
    (102, 'Jane Smith', 'jane.smith@email.com', 62000.00, 'HR'),
    (103, 'Robert Brown', 'robert.b@email.com', 48000.00, 'Finance');

-- 3. Update rows
UPDATE Employee
SET Salary = 65000.00
WHERE EmpID = 102;

-- 4. Delete rows
DELETE FROM Employee
WHERE EmpID = 103;