-- 3   b) write a PL SQL Trigger program to update the book details in library management system after purchasing books.

-- 1. DDL: Create Tables
-- Table to store current book details and stock levels
CREATE TABLE Book_Inventory (
    Book_ID INT PRIMARY KEY,
    Title VARCHAR(100),
    Stock_Quantity INT DEFAULT 0
);

-- Table to record new purchases of books
CREATE TABLE Book_Purchases (
    Purchase_ID INT PRIMARY KEY,
    Book_ID INT,
    Quantity_Bought INT,
    Purchase_Date DATE DEFAULT CURRENT_DATE,
    FOREIGN KEY (Book_ID) REFERENCES Book_Inventory(Book_ID)
);

-- 2. DML: Initial Inventory Setup
INSERT INTO Book_Inventory VALUES (101, 'Database System Concepts', 10);
INSERT INTO Book_Inventory VALUES (102, 'Java Programming', 5);
COMMIT;

-- 3. PL/SQL Trigger: Update Stock after Purchase
SET SERVEROUTPUT ON;

CREATE OR REPLACE TRIGGER TRG_Update_Library_Stock
AFTER INSERT ON Book_Purchases
FOR EACH ROW
BEGIN
    -- Update the inventory by adding the newly purchased quantity
    UPDATE Book_Inventory
    SET Stock_Quantity = Stock_Quantity + :NEW.Quantity_Bought
    WHERE Book_ID = :NEW.Book_ID;

    DBMS_OUTPUT.PUT_LINE('STOCK UPDATED: Added ' || :NEW.Quantity_Bought || ' copies to Book ID ' || :NEW.Book_ID);
END;
/

-- ==========================================
-- 4. Test Execution (What the examiner will see)
-- ==========================================

-- Check stock before purchase (Should be 10)
-- SELECT Stock_Quantity FROM Book_Inventory WHERE Book_ID = 101;

-- Perform a purchase (Insert into the purchase table)
-- INSERT INTO Book_Purchases VALUES (1, 101, 5, CURRENT_DATE);

-- Check stock after purchase (Should now be 15)
-- SELECT Stock_Quantity FROM Book_Inventory WHERE Book_ID = 101;