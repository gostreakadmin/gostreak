'''7.	Write a program to implement the naïve Bayesian classifier for a sample training data set stored as a .CSV file. Compute the accuracy of the classifier, considering few test data sets.'''


import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score

# 1. Load the dataset from CSV
try:
    df = pd.read_csv('data.csv')
    print("Dataset loaded successfully!")
except FileNotFoundError:
    print("Error: data.csv not found. Please create the file first.")
    exit()

# 2. Preprocess: Naive Bayes requires numerical input
# We use LabelEncoder to convert strings (Sunny, Hot, etc.) to numbers
le = LabelEncoder()
for col in df.columns:
    df[col] = le.fit_transform(df[col])

# 3. Split features (X) and target (y)
X = df.drop('Play', axis=1) # All columns except the last one
y = df['Play']              # The 'Play' column (target)

# 4. Split into Training and Testing sets (e.g., 80% train, 20% test)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 5. Build and Train the Naive Bayesian Classifier
model = GaussianNB()
model.fit(X_train, y_train)

# 6. Predict and Compute Accuracy
y_pred = model.predict(X_test)
accuracy = accuracy_score(y_test, y_pred)

print(f"\n--- Results ---")
print(f"Test Data Predictions: {y_pred}")
print(f"Actual Test Labels:    {y_test.values}")
print(f"Accuracy: {accuracy * 100:.2f}%")

# 7. Classify a specific new sample
# Example: Outlook=Sunny(2), Temp=Mild(2), Humidity=Normal(1), Wind=Weak(1)
new_data = [[2, 2, 1, 1]]
new_pred = model.predict(new_data)
print(f"New Sample Prediction: {'Yes' if new_pred[0] == 1 else 'No'}")

'''
output:
Dataset loaded successfully!

--- Results ---
Test Data Predictions: [1 0]
Actual Test Labels:    [1 0]
Accuracy: 100.00%

New Sample Prediction: Yes'''