'''11.	For a given set of training data examples stored in a .CSV file, implement and demonstrate the Candidate-Elimination algorithm to output a description of the set of all hypotheses consistent with the training examples.'''

import pandas as pd
import numpy as np

def learn(concepts, target):
    # Initialize Specific boundary with the first positive example
    specific_h = concepts[0].copy()
    # Initialize General boundary with '?'
    general_h = [["?" for _ in range(len(specific_h))] for _ in range(len(specific_h))]

    for i, h in enumerate(concepts):
        if target[i] == "Yes":  # Positive Example
            for x in range(len(specific_h)):
                if h[x] != specific_h[x]:
                    specific_h[x] = '?'
                    general_h[x][x] = '?'

        else:  # Negative Example
            for x in range(len(specific_h)):
                if h[x] != specific_h[x]:
                    general_h[x][x] = specific_h[x]
                else:
                    general_h[x][x] = '?'

    # Remove empty sets from general_h
    indices = [i for i, val in enumerate(general_h) if val == ['?', '?', '?', '?', '?', '?']]
    for i in reversed(indices):
        general_h.pop(i)
        
    return specific_h, general_h

# 1. Load Dataset
try:
    data = pd.read_csv('training_data.csv')
    concepts = np.array(data.iloc[:, 0:-1])
    target = np.array(data.iloc[:, -1])
    
    s_final, g_final = learn(concepts, target)
    
    print("--- Candidate Elimination Results ---")
    print(f"Final Specific Boundary (S): {s_final}")
    print(f"Final General Boundary (G): {g_final}")

except FileNotFoundError:
    print("Please ensure 'training_data.csv' exists in the directory.")

    '''
    output:
    --- Candidate Elimination Results ---
Final Specific Boundary (S): ['Sunny' 'Warm' '?' 'Strong' '?' '?']
Final General Boundary (G): [['Sunny', '?', '?', '?', '?', '?'], ['?', 'Warm', '?', '?', '?', '?']]
'''