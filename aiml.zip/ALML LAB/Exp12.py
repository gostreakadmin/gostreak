'''12.	Implement and demonstrate the FIND-S algorithm for finding the most specific hypothesis based on a given set of training data samples. Read the training data from a .CSV file'''

import pandas as pd
import numpy as np

def find_s(concepts, target):
    # Initialize the specific hypothesis with the first positive example
    for i, val in enumerate(target):
        if val == "Yes":
            specific_h = concepts[i].copy()
            break
            
    print(f"Initial Specific Hypothesis: {specific_h}")

    for i, h in enumerate(concepts):
        if target[i] == "Yes":
            for x in range(len(specific_h)):
                if h[x] != specific_h[x]:
                    # Generalize if the attribute doesn't match
                    specific_h[x] = '?'
            print(f"Hypothesis after positive example {i+1}: {specific_h}")
            
    return specific_h

# 1. Load Dataset
try:
    # Example: training_data.csv with columns: Sky,Temp,Humid,Wind,Water,Forecast,EnjoySport
    df = pd.read_csv('training_data.csv')
    concepts = np.array(df.iloc[:, 0:-1])
    target = np.array(df.iloc[:, -1])
    
    final_h = find_s(concepts, target)
    
    print("\n--- Final Most Specific Hypothesis ---")
    print(final_h)

except FileNotFoundError:
    print("Error: 'training_data.csv' not found.")

    '''
    output:
    Initial Specific Hypothesis: ['Sunny' 'Warm' 'Normal' 'Strong' 'Warm' 'Same']
Hypothesis after positive example 1: ['Sunny' 'Warm' 'Normal' 'Strong' 'Warm' 'Same']
Hypothesis after positive example 2: ['Sunny' 'Warm' '?' 'Strong' 'Warm' 'Same']
Hypothesis after positive example 4: ['Sunny' 'Warm' '?' 'Strong' '?' '?']

--- Final Most Specific Hypothesis ---
['Sunny' 'Warm' '?' 'Strong' '?' '?']
'''