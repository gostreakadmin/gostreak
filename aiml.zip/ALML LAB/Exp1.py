'''1.	Implementation of Depth First Search for Water Jug Problem '''

def dfs_water_jug(amt1, amt2, cap1, cap2, goal, visited, path):
    # If goal is reached in either jug
    if amt1 == goal or amt2 == goal:
        path.append((amt1, amt2))
        return True

    # Check if this state has already been visited
    if (amt1, amt2) in visited:
        return False
    
    visited.add((amt1, amt2))
    path.append((amt1, amt2))

    # Possible transitions (Rules)
    rules = [
        (cap1, amt2),           # Fill Jug 1
        (amt1, cap2),           # Fill Jug 2
        (0, amt2),              # Empty Jug 1
        (amt1, 0),              # Empty Jug 2
        # Pour Jug 2 -> Jug 1
        (min(amt1 + amt2, cap1), amt2 - (min(amt1 + amt2, cap1) - amt1)),
        # Pour Jug 1 -> Jug 2
        (amt1 - (min(amt1 + amt2, cap2) - amt2), min(amt1 + amt2, cap2))
    ]

    for next_amt1, next_amt2 in rules:
        if dfs_water_jug(next_amt1, next_amt2, cap1, cap2, goal, visited, path):
            return True
    
    # Backtrack if no rule leads to the goal
    path.pop()
    return False

# Parameters
j1_cap, j2_cap, target = 4, 3, 2
solution_path = []

print(f"Searching for {target}L using jugs of {j1_cap}L and {j2_cap}L...")
if dfs_water_jug(0, 0, j1_cap, j2_cap, target, set(), solution_path):
    print("Steps to reach the goal:")
    for step in solution_path:
        print(step)
else:
    print("No solution found.")

'''
Output:
Searching for 2L using jugs of 4L and 3L...
Steps to reach the goal:
(0, 0)
(4, 0)
(4, 3)
(0, 3)
(3, 0)
(3, 3)
(4, 2)
'''