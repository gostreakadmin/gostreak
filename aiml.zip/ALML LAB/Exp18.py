'''18.	Write a program to implement Hill Climbing algorithm.'''

import random

def objective_function(x):
    # This is the "Hill" we are climbing. 
    # The peak is at x = 5 where the value is 10.
    return -(x - 5)**2 + 10

def hill_climbing(start_x, step_size, max_iterations):
    current_x = start_x
    current_value = objective_function(current_x)
    
    print(f"Starting at x = {current_x:.2f}, value = {current_value:.2f}")

    for i in range(max_iterations):
        # 1. Look at neighbors (left and right)
        next_x_left = current_x - step_size
        next_x_right = current_x + step_size
        
        # 2. Evaluate neighbors
        val_left = objective_function(next_x_left)
        val_right = objective_function(next_x_right)
        
        # 3. Move to the best neighbor if it's better than current
        if val_left > current_value and val_left >= val_right:
            current_x = next_x_left
            current_value = val_left
        elif val_right > current_value:
            current_x = next_x_right
            current_value = val_right
        else:
            # If no neighbor is better, we reached a peak (or local maximum)
            print(f"Reached peak at iteration {i}")
            break
            
    return current_x, current_value

# Parameters
start_point = random.uniform(0, 10)  # Random starting position
step = 0.1                           # How far we move each step
iterations = 100

best_x, best_val = hill_climbing(start_point, step, iterations)

print("\n--- Hill Climbing Results ---")
print(f"Final x: {best_x:.4f}")
print(f"Final Value: {best_val:.4f}")

'''output:
Starting at x = 2.45, value = 3.50
Reached peak at iteration 26

--- Hill Climbing Results ---
Final x: 5.0500
Final Value: 9.9975
'''