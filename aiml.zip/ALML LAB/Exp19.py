'''19.	Write a program to implement Towers of Hanoi problem.'''

def towers_of_hanoi(n, source, destination, auxiliary):
    if n == 1:
        print(f"Move disk 1 from {source} to {destination}")
        return

    # Step 1: Move n-1 disks from source to auxiliary
    towers_of_hanoi(n - 1, source, auxiliary, destination)

    # Step 2: Move the nth disk from source to destination
    print(f"Move disk {n} from {source} to {destination}")

    # Step 3: Move the n-1 disks from auxiliary to destination
    towers_of_hanoi(n - 1, auxiliary, destination, source)

# Number of disks
n_disks = 3

print(f"Steps to solve Towers of Hanoi with {n_disks} disks:")
towers_of_hanoi(n_disks, 'A', 'C', 'B')

'''
output: 
Steps to solve Towers of Hanoi with 3 disks:
Move disk 1 from A to C
Move disk 2 from A to B
Move disk 1 from C to B
Move disk 3 from A to C
Move disk 1 from B to A
Move disk 2 from B to C
Move disk 1 from A to C
'''