'''16. ii.	Creation and loading different datasets in python. '''

import pandas as pd
import numpy as np
from sklearn.datasets import load_iris

# --- 1. CREATING A DATASET MANUALLY ---
print("--- Step 1: Creating a Dataset ---")
data = {
    'Outlook': ['Sunny', 'Sunny', 'Overcast', 'Rain'],
    'Temp': [30, 32, 28, 22],
    'Humidity': ['High', 'High', 'Normal', 'Normal'],
    'Play': ['No', 'No', 'Yes', 'Yes']
}
df_manual = pd.DataFrame(data)
print(df_manual)

# --- 2. SAVING AND LOADING CSV ---
print("\n--- Step 2: Saving to CSV and Reloading ---")
df_manual.to_csv('lab_data.csv', index=False)
df_reloaded = pd.read_csv('lab_data.csv')
print("Reloaded from CSV:\n", df_reloaded.head(2))

# --- 3. LOADING BUILT-IN DATASET (IRIS) ---
print("\n--- Step 3: Loading Scikit-Learn Iris Dataset ---")
iris = load_iris()
# Combine data and target into one DataFrame
df_iris = pd.DataFrame(data=iris.data, columns=iris.feature_names)
df_iris['target'] = iris.target
print("Iris Data Shape:", df_iris.shape)
print(df_iris.head())

# --- 4. EXPLORING DATASET PROPERTIES ---
print("\n--- Step 4: Dataset Statistics ---")
print("Basic Info:")
print(df_iris.info())
print("\nStatistical Summary:")
print(df_iris.describe())

'''
output:
--- Step 1: Creating a Dataset ---
    Outlook  Temp Humidity Play
0     Sunny    30     High   No
1     Sunny    32     High   No
2  Overcast    28   Normal  Yes
3      Rain    22   Normal  Yes

--- Step 2: Saving to CSV and Reloading ---
Reloaded from CSV:
   Outlook  Temp Humidity Play
0   Sunny    30     High   No
1   Sunny    32     High   No

--- Step 3: Loading Scikit-Learn Iris Dataset ---
Iris Data Shape: (150, 5)
   sepal length (cm)  sepal width (cm)  petal length (cm)  petal width (cm)  target
0                5.1               3.5                1.4               0.2       0
1                4.9               3.0                1.4               0.2       0
2                4.7               3.2                1.3               0.2       0

--- Step 4: Dataset Statistics ---
Basic Info:
<class 'pandas.core.frame.DataFrame'>
RangeIndex: 150 entries, 0 to 149
Data columns (total 5 columns):
...
Statistical Summary:
       sepal length (cm)  sepal width (cm)  petal length (cm)  petal width (cm)      target
count         150.000000        150.000000         150.000000        150.000000  150.000000
mean            5.843333          3.057333           3.758000          1.199333    1.000000
...
'''