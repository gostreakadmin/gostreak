'''16.	i. Implementation of Candidate Elimination Algorithm'''

import pandas as pd
import numpy as np

def learn(concepts, target):
    # Initialize Specific boundary with the first positive example
    specific_h = concepts[0].copy()
    # Initialize General boundary with '?' (most general)
    general_h = [["?" for _ in range(len(specific_h))] for _ in range(len(specific_h))]

    for i, h in enumerate(concepts):
        if target[i] == "Yes":  # Positive Example
            for x in range(len(specific_h)):
                # If specific hypothesis doesn't match, generalize it
                if h[x] != specific_h[x]:
                    specific_h[x] = '?'
                    general_h[x][x] = '?'

        else:  # Negative Example
            for x in range(len(specific_h)):
                # If negative example contradicts specific_h, specialize general_h
                if h[x] != specific_h[x]:
                    general_h[x][x] = specific_h[x]
                else:
                    general_h[x][x] = '?'

    # Filter out redundant general hypotheses
    indices = [i for i, val in enumerate(general_h) if val == ['?'] * len(specific_h)]
    for i in reversed(indices):
        general_h.pop(i)
        
    return specific_h, general_h

# Load Dataset
try:
    data = pd.read_csv('training_data.csv')
    concepts = np.array(data.iloc[:, 0:-1])
    target = np.array(data.iloc[:, -1])
    
    s_final, g_final = learn(concepts, target)
    
    print("--- Candidate Elimination Results ---")
    print(f"Final Specific Boundary (S): {s_final}")
    print(f"Final General Boundary (G): {g_final}")

except FileNotFoundError:
    print("Error: 'training_data.csv' not found.")

    '''
    output:
    --- Candidate Elimination Results ---
Final Specific Boundary (S): ['Sunny' 'Warm' '?' 'Strong' '?' '?']
Final General Boundary (G): [['Sunny', '?', '?', '?', '?', '?'], ['?', 'Warm', '?', '?', '?', '?']]
'''