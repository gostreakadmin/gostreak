'''20. Write a Program to Implement Monkey Banana Problem using Python.'''

class MonkeyBananaProblem:
    def __init__(self):
        # Initial State: (Monkey at A, Box at B, Monkey on Floor, No Banana)
        self.state = ('A', 'B', 'on-floor', 'no')
        self.target_pos = 'C'  # Banana is hanging at position C

    def move(self, pos):
        m_pos, b_pos, on_box, has_b = self.state
        if on_box == 'on-floor':
            print(f"Action: Monkey moves from {m_pos} to {pos}")
            self.state = (pos, b_pos, on_box, has_b)
        else:
            print("Cannot move while on the box!")

    def push(self, pos):
        m_pos, b_pos, on_box, has_b = self.state
        if m_pos == b_pos and on_box == 'on-floor':
            print(f"Action: Monkey pushes box from {b_pos} to {pos}")
            self.state = (pos, pos, on_box, has_b)
        else:
            print("Monkey must be at the box and on the floor to push it.")

    def climb(self):
        m_pos, b_pos, on_box, has_b = self.state
        if m_pos == b_pos:
            print("Action: Monkey climbs onto the box")
            self.state = (m_pos, b_pos, 'on-box', has_b)
        else:
            print("Monkey is not at the box's location.")

    def grasp(self):
        m_pos, b_pos, on_box, has_b = self.state
        if m_pos == self.target_pos and on_box == 'on-box':
            print("Action: Monkey grasps the banana!")
            self.state = (m_pos, b_pos, on_box, 'yes')
        else:
            print("Monkey cannot reach the banana yet.")

# Simulation
problem = MonkeyBananaProblem()

# Execution of the steps
problem.move('B')       # Move to box location
problem.push('C')       # Push box to banana location
problem.climb()         # Climb the box
problem.grasp()         # Grab the banana

if problem.state[3] == 'yes':
    print("\nSuccess: Monkey has the banana!")

    '''
    output:
    Action: Monkey moves from A to B
Action: Monkey pushes box from B to C
Action: Monkey climbs onto the box
Action: Monkey grasps the banana!

Success: Monkey has the banana!
'''