'''13.	Write a Program to Implement N-Queens Problem using Python'''

def is_safe(board, row, col, n):
    # Check this column on upper side
    for i in range(row):
        if board[i][col] == 'Q':
            return False

    # Check upper left diagonal
    for i, j in zip(range(row, -1, -1), range(col, -1, -1)):
        if board[i][j] == 'Q':
            return False

    # Check upper right diagonal
    for i, j in zip(range(row, -1, -1), range(col, n)):
        if board[i][j] == 'Q':
            return False

    return True

def solve_n_queens(board, row, n):
    # If all queens are placed, return True
    if row >= n:
        return True

    for col in range(n):
        if is_safe(board, row, col, n):
            # Place queen
            board[row][col] = 'Q'

            # Recur to place rest of the queens
            if solve_n_queens(board, row + 1, n):
                return True

            # If placing queen doesn't lead to a solution, backtrack
            board[row][col] = '.'

    return False

def print_board(board):
    for row in board:
        print(" ".join(row))

# Set board size
N = 4
chess_board = [['.' for _ in range(N)] for _ in range(N)]

if solve_n_queens(chess_board, 0, N):
    print(f"Solution for {N}-Queens:")
    print_board(chess_board)
else:
    print("No solution exists.")

'''output:
Solution for 4-Queens:
. Q . .
. . . Q
Q . . .
. . Q .
'''