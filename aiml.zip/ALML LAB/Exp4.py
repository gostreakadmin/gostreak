'''4.	Assuming a set of documents that need to be classified, use the naïve Bayesian Classifier model to perform this task. Built-in Java classes/API can be used to write the program. Calculate the accuracy, precision, and recall for your data set.'''

from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.model_selection import train_test_split
from sklearn import metrics

# 1. Sample Data: Documents and their Labels (0: Ham/Normal, 1: Spam)
documents = [
    'Free money now click here', 
    'Hi, are we meeting for lunch today?',
    'Win a brand new car today only', 
    'Please review the attached project report',
    'Urgent: Your account has been suspended',
    'Call me when you are free'
]
labels = [1, 0, 1, 0, 1, 0]  # 1 for Spam, 0 for Ham

# 2. Convert text data into a Matrix of token counts (Vectorization)
vectorizer = CountVectorizer()
X = vectorizer.fit_transform(documents)

# 3. Split data into Training and Testing sets (usually 80-20 or 70-30)
# For a lab demo, we'll use a small test size
X_train, X_test, y_train, y_test = train_test_split(X, labels, test_size=0.3, random_state=42)

# 4. Initialize and Train the Naive Bayes Classifier
model = MultinomialNB()
model.fit(X_train, y_train)

# 5. Make Predictions
predicted = model.predict(X_test)

# 6. Calculate Accuracy, Precision, and Recall
accuracy = metrics.accuracy_score(y_test, predicted)
precision = metrics.precision_score(y_test, predicted)
recall = metrics.recall_score(y_test, predicted)

print("--- Naive Bayes Classification Results ---")
print(f"Accuracy:  {accuracy * 100:.2f}%")
print(f"Precision: {precision:.2f}")
print(f"Recall:    {recall:.2f}")

# Optional: Print Confusion Matrix
print("\nConfusion Matrix:")
print(metrics.confusion_matrix(y_test, predicted))

'''
output:
--- Naive Bayes Classification Results ---
Accuracy:  100.00%
Precision: 1.00
Recall:    1.00

Confusion Matrix:
[[1 0]
 [0 1]]
 '''