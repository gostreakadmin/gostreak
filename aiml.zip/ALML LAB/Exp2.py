'''2.	Implementation of Breadth First Search for Tic-Tac-Toe Problem'''

from collections import deque

def check_win(board, player):
    # Winning combinations: Rows, Cols, Diagonals
    win_states = [
        [0, 1, 2], [3, 4, 5], [6, 7, 8], # Rows
        [0, 3, 6], [1, 4, 7], [2, 5, 8], # Cols
        [0, 4, 8], [2, 4, 6]             # Diagonals
    ]
    return any(all(board[i] == player for i in combo) for combo in win_states)

def bfs_tic_tac_toe(start_board, player):
    # Queue stores (current_board, path_taken)
    queue = deque([(start_board, [])])
    visited = set()
    visited.add(tuple(start_board))

    while queue:
        current_board, path = queue.popleft()

        # If current player wins, return the path
        if check_win(current_board, player):
            return path + [current_board]

        # Try all possible moves
        for i in range(9):
            if current_board[i] == ' ':
                new_board = list(current_board)
                new_board[i] = player
                
                if tuple(new_board) not in visited:
                    visited.add(tuple(new_board))
                    # Note: In a real game, players alternate. 
                    # This BFS finds the fastest way 'X' can fill the board to win.
                    queue.append((new_board, path + [current_board]))
    return None

def print_board(board):
    for i in range(0, 9, 3):
        print(f"{board[i]} | {board[i+1]} | {board[i+2]}")
    print("-" * 9)

# Initial Board (X's turn, some spots taken)
start = ['X', 'O', ' ', 
         ' ', 'O', ' ', 
         'X', ' ', ' ']

print("Initial State:")
print_board(start)

solution = bfs_tic_tac_toe(start, 'X')

if solution:
    print("Winning Path found via BFS:")
    for step in solution:
        print_board(step)
else:
    print("No winning move possible.")

'''
output:
Initial State:
X | O |  
  | O |  
X |   |  
---------
Winning Path found via BFS:
X | O |  
  | O |  
X |   |  
---------
X | O |  
X | O |  
X |   |  
---------

'''