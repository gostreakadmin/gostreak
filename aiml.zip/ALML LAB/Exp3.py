'''3.	Solve 8-puzzle problem using Best First Search'''

import heapq

def get_manhattan_distance(state, goal):
    distance = 0
    for i in range(9):
        if state[i] != 0:  # Skip the empty tile
            current_idx = i
            goal_idx = goal.index(state[i])
            # Calculate row and column differences
            distance += abs(current_idx // 3 - goal_idx // 3) + \
                        abs(current_idx % 3 - goal_idx % 3)
    return distance

def get_neighbors(state):
    neighbors = []
    idx = state.index(0)  # Find the empty tile
    row, col = idx // 3, idx % 3
    
    # Possible moves: Up, Down, Left, Right
    moves = [(-1, 0), (1, 0), (0, -1), (0, 1)]
    
    for dr, dc in moves:
        nr, nc = row + dr, col + dc
        if 0 <= nr < 3 and 0 <= nc < 3:
            new_state = list(state)
            new_idx = nr * 3 + nc
            new_state[idx], new_state[new_idx] = new_state[new_idx], new_state[idx]
            neighbors.append(tuple(new_state))
    return neighbors

def best_first_search(start, goal):
    # Priority Queue stores: (heuristic_value, current_state, path)
    pq = [(get_manhattan_distance(start, goal), start, [])]
    visited = set()
    
    while pq:
        h, current, path = heapq.heappop(pq)
        
        if current == goal:
            return path + [current]
        
        if current in visited:
            continue
            
        visited.add(current)
        
        for neighbor in get_neighbors(current):
            if neighbor not in visited:
                priority = get_manhattan_distance(neighbor, goal)
                heapq.heappush(pq, (priority, neighbor, path + [current]))
    return None

def print_puzzle(state):
    for i in range(0, 9, 3):
        print(f"{state[i]} {state[i+1]} {state[i+2]}")
    print("---")

# 0 represents the empty space
start_state = (1, 2, 3, 
               4, 0, 5, 
               7, 8, 6)

goal_state = (1, 2, 3, 
              4, 5, 6, 
              7, 8, 0)

print("Start State:")
print_puzzle(start_state)

solution = best_first_search(start_state, goal_state)

if solution:
    print(f"Goal Reached in {len(solution)-1} moves:")
    for step in solution:
        print_puzzle(step)
else:
    print("No solution found.")

'''
output:

Start State:
1 2 3
4 0 5
7 8 6
---
Goal Reached in 2 moves:
1 2 3
4 0 5
7 8 6
---
1 2 3
4 5 0
7 8 6
---
1 2 3
4 5 6
7 8 0
---
'''