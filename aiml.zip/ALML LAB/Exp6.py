'''6.	Write a program to demonstrate the working of the decision tree based ID3 algorithm. Use an appropriate data set for building the decision tree and apply this knowledge to classify a new sample.'''

import pandas as pd
from sklearn.tree import DecisionTreeClassifier, export_text
from sklearn.preprocessing import LabelEncoder

# 1. Create the Dataset (Play Tennis)
data = {
    'Outlook': ['Sunny', 'Sunny', 'Overcast', 'Rain', 'Rain', 'Rain', 'Overcast', 'Sunny', 'Sunny', 'Rain'],
    'Temp': ['Hot', 'Hot', 'Hot', 'Mild', 'Cool', 'Cool', 'Cool', 'Mild', 'Cool', 'Mild'],
    'Humidity': ['High', 'High', 'High', 'High', 'Normal', 'Normal', 'Normal', 'High', 'Normal', 'Normal'],
    'Wind': ['Weak', 'Strong', 'Weak', 'Weak', 'Weak', 'Strong', 'Strong', 'Weak', 'Weak', 'Weak'],
    'Play': ['No', 'No', 'Yes', 'Yes', 'Yes', 'No', 'Yes', 'No', 'Yes', 'Yes']
}

df = pd.DataFrame(data)

# 2. Preprocess: Convert strings to numbers (Label Encoding)
le = LabelEncoder()
for col in df.columns:
    df[col] = le.fit_transform(df[col])

X = df.drop('Play', axis=1) # Features
y = df['Play']              # Target

# 3. Build the ID3 Model (using entropy)
# max_depth is kept small for demonstration
model = DecisionTreeClassifier(criterion='entropy')
model.fit(X, y)

# 4. Classify a New Sample
# New sample: Outlook=Rain(2), Temp=Cool(0), Humidity=Normal(1), Wind=Strong(0)
new_sample = [[2, 0, 1, 0]]
prediction = model.predict(new_sample)
result = "Yes" if prediction[0] == 1 else "No"

print("--- ID3 Decision Tree Results ---")
print(f"Prediction for new sample: {result}")

# 5. Visualize the Tree Structure in Text
tree_rules = export_text(model, feature_names=list(X.columns))
print("\nGenerated Decision Tree Rules:")
print(tree_rules)

'''
output:
--- ID3 Decision Tree Results ---
Prediction for new sample: Yes

Generated Decision Tree Rules:
|--- Outlook <= 1.50
|   |--- Wind <= 0.50
|   |   |--- Outlook <= 0.50
|   |   |   |--- class: 1
|   |   |--- Outlook >  0.50
|   |   |   |--- class: 0
|   |--- Wind >  0.50
|   |   |--- class: 1
|--- Outlook >  1.50
|   |--- Temp <= 0.50
|   |   |--- class: 1
|   |--- Temp >  0.50
|   |   |--- class: 0
'''