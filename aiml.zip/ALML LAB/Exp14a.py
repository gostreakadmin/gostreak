'''14.	i. Write a python program to implement Simple Linear Regression and plot the graph'''

import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression

# 1. Prepare the Data
# x: Independent variable (e.g., Hours Studied)
# y: Dependent variable (e.g., Exam Score)
x = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]).reshape(-1, 1)
y = np.array([2, 3, 5, 7, 11, 13, 17, 19, 23, 25])

# 2. Initialize and Train the Model
model = LinearRegression()
model.fit(x, y)

# 3. Make Predictions
y_pred = model.predict(x)

# 4. Extract Coefficients
slope = model.coef_[0]
intercept = model.intercept_

print(f"--- Linear Regression Results ---")
print(f"Slope (m): {slope:.2f}")
print(f"Intercept (c): {intercept:.2f}")
print(f"Equation: y = {slope:.2f}x + {intercept:.2f}")

# 5. Plot the Graph
plt.figure(figsize=(10, 6))
plt.scatter(x, y, color='blue', label='Actual Data (Scatter)')
plt.plot(x, y_pred, color='red', linewidth=2, label='Regression Line (Best Fit)')
plt.title('Simple Linear Regression')
plt.xlabel('Independent Variable (x)')
plt.ylabel('Dependent Variable (y)')
plt.legend()
plt.grid(True, linestyle='--', alpha=0.6)
plt.show()

'''
output:
--- Linear Regression Results ---
Slope (m): 2.62
Intercept (c): -1.40
Equation: y = 2.62x + -1.40
'''