'''9.	Write a program to implement k-Nearest Neighbour algorithm to classify the iris data set. Print both correct and wrong predictions. Java/Python ML library classes can be used for this problem.'''

from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score

# 1. Load the Iris dataset
iris = load_iris()
X = iris.data
y = iris.target
target_names = iris.target_names

# 2. Split the data (80% training, 20% testing)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 3. Initialize kNN Classifier (k=3)
knn = KNeighborsClassifier(n_neighbors=3)
knn.fit(X_train, y_train)

# 4. Make Predictions
y_pred = knn.predict(X_test)

# 5. Print Correct and Wrong Predictions
print(f"{'Actual Label':<20} | {'Predicted Label':<20} | {'Status'}")
print("-" * 55)

for i in range(len(y_test)):
    actual = target_names[y_test[i]]
    predicted = target_names[y_pred[i]]
    status = "Correct" if y_test[i] == y_pred[i] else "WRONG"
    print(f"{actual:<20} | {predicted:<20} | {status}")

# 6. Final Accuracy
print("-" * 55)
print(f"Total Accuracy: {accuracy_score(y_test, y_pred) * 100:.2f}%")

'''output:
Actual Label         | Predicted Label      | Status
-------------------------------------------------------
versicolor           | versicolor           | Correct
setosa               | setosa               | Correct
virginica            | virginica            | Correct
versicolor           | versicolor           | Correct
versicolor           | versicolor           | Correct
setosa               | setosa               | Correct
...
virginica            | virginica            | Correct
-------------------------------------------------------
Total Accuracy: 100.00%
'''