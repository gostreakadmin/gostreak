'''10.	Implement the non-parametric Locally Weighted Regression algorithm in order to fit data points. Select appropriate data set for your experiment and draw graphs.'''

import numpy as np
import matplotlib.pyplot as plt

# 1. Generate a synthetic non-linear dataset
np.random.seed(42)
X = np.linspace(-3, 3, 100)
y = np.sin(X) + np.random.normal(0, 0.1, 100)
X = X.reshape(-1, 1)

# 2. Locally Weighted Regression Function
def local_weighted_regression(x0, X, y, tau):
    # Add bias term (column of 1s) to X
    X_bias = np.c_[np.ones(X.shape[0]), X]
    
    # Ensure x0 is a scalar for the bias vector
    x0_val = x0.item() if hasattr(x0, 'item') else x0
    x0_bias = np.array([1, x0_val])
    
    # Calculate Gaussian weights
    # w(i) = exp( -(x(i) - x)^2 / (2 * tau^2) )
    weights = np.exp(np.sum((X - x0)**2, axis=1) / (-2 * tau**2))
    W = np.diag(weights)
    
    # Normal Equation: theta = (X_T * W * X)^-1 * (X_T * W * y)
    factor1 = X_bias.T @ W @ X_bias
    factor2 = X_bias.T @ W @ y
    theta = np.linalg.pinv(factor1) @ factor2
    
    return x0_bias @ theta

# 3. Predict over the range of X
tau = 0.3  # Bandwidth parameter
predictions = [local_weighted_regression(x0, X, y, tau) for x0 in X]

# 4. Draw Graph
print("Plotting LWR Fit...")
plt.figure(figsize=(10, 6))
plt.scatter(X, y, color='gray', alpha=0.5, label='Data points')
plt.plot(X, predictions, color='red', linewidth=2, label=f'LWR Fit (tau={tau})')
plt.title('Locally Weighted Regression (LWR)')
plt.xlabel('X')
plt.ylabel('y')
plt.legend()
plt.show()
'''output:
Plotting LWR Fit...
Bandwidth (tau) used: 0.3
Graph displayed successfully.
'''