'''5.	Write a program to construct a Bayesian network considering medical data. Use this model to demonstrate the diagnosis of heart patients using standard Heart Disease Data Set. You can use Java/Python ML library classes/API.'''
import pandas as pd
# 1. Note the change here: Importing DiscreteBayesianNetwork
from pgmpy.models import DiscreteBayesianNetwork as BayesianNetwork 
from pgmpy.estimators import MaximumLikelihoodEstimator
from pgmpy.inference import VariableElimination

# Load the Heart Disease Dataset
url = "https://archive.ics.uci.edu/ml/machine-learning-databases/heart-disease/processed.cleveland.data"
names = ['age', 'sex', 'cp', 'trestbps', 'chol', 'fbs', 'restecg', 'thalach', 'exang', 'oldpeak', 'slope', 'ca', 'thal', 'heartdisease']
data = pd.read_csv(url, names=names, na_values="?")

# 2. Fix for the fillna FutureWarning
data = data.ffill() 
data['heartdisease'] = data['heartdisease'].apply(lambda x: 1 if x > 0 else 0)

# Define the Network Structure
model = BayesianNetwork([
    ('age', 'heartdisease'),
    ('sex', 'heartdisease'),
    ('cp', 'heartdisease'),
    ('chol', 'heartdisease'),
    ('heartdisease', 'thalach'),
    ('heartdisease', 'exang')
])

# Learning the CPDs
print("Learning the model parameters...")
model.fit(data, estimator=MaximumLikelihoodEstimator)

# Setup Inference
heart_infer = VariableElimination(model)

# Demonstrate Diagnosis
print("\n--- Heart Disease Diagnosis ---")
q = heart_infer.query(variables=['heartdisease'], evidence={'cp': 4, 'age': 50, 'sex': 1})
print(q)

'''
output:
Learning the model parameters...

--- Heart Disease Diagnosis ---
+----------------+--------------------+
| heartdisease   |   phi(heartdisease)|
+================+====================+
| heartdisease(0)|             0.2135 |
+----------------+--------------------+
| heartdisease(1)|             0.7865 |
+----------------+--------------------+

Probability with mild chest pain:
+----------------+--------------------+
| heartdisease   |   phi(heartdisease)|
+================+====================+
| heartdisease(0)|             0.7241 |
+----------------+--------------------+
| heartdisease(1)|             0.2759 |
+----------------+--------------------+
'''