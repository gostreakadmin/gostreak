'''8.	Apply EM algorithm to cluster a set of data stored in a .CSV file. Use the same data set for clustering using k-Means algorithm. Compare the results of these two algorithms and comment on the quality of clustering. You can add Java/Python ML library classes/API in the program.'''

import pandas as pd
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.mixture import GaussianMixture 
from sklearn.preprocessing import StandardScaler
from sklearn import metrics

# 1. Load Dataset
try:
    df = pd.read_csv('clustering_data.csv')
    X = df.iloc[:, [0, 1]].values 

    # Standardize features
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    # 2. k-Means Clustering (Hard Clustering)
    kmeans = KMeans(n_clusters=3, random_state=42)
    km_labels = kmeans.fit_predict(X_scaled)

    # 3. EM Algorithm / GMM (Soft Clustering)
    # Note: Use n_components here
    gmm = GaussianMixture(n_components=3, random_state=42)
    gmm_labels = gmm.fit_predict(X_scaled)

    # 4. Compare Results using Silhouette Score
    km_score = metrics.silhouette_score(X_scaled, km_labels)
    gmm_score = metrics.silhouette_score(X_scaled, gmm_labels)

    print(f"k-Means Silhouette Score: {km_score:.4f}")
    print(f"EM (GMM) Silhouette Score: {gmm_score:.4f}")

    # 5. Visualization
    plt.figure(figsize=(12, 5))

    # Plot k-Means
    plt.subplot(1, 2, 1)
    plt.scatter(X_scaled[:, 0], X_scaled[:, 1], c=km_labels, cmap='viridis')
    plt.title(f'k-Means (Score: {km_score:.2f})')

    # Plot EM (GMM)
    plt.subplot(1, 2, 2)
    plt.scatter(X_scaled[:, 0], X_scaled[:, 1], c=gmm_labels, cmap='magma')
    plt.title(f'EM / GMM (Score: {gmm_score:.2f})')

    plt.tight_layout()
    plt.show()

except Exception as e:
    print(f"An error occurred: {e}")
    
'''
output:
k-Means Silhouette Score: 0.6214
EM (GMM) Silhouette Score: 0.6582
'''