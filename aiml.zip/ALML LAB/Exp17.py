'''17.	Write a program to implement informed search algorithm. (Write A* algorithm)'''

import heapq

def a_star_search(graph, heuristics, start, goal):
    # Priority Queue stores: (f_score, current_node, path, g_score)
    priority_queue = [(heuristics[start], start, [start], 0)]
    visited = {}

    while priority_queue:
        f, current, path, g = heapq.heappop(priority_queue)

        if current == goal:
            return path, g

        if current in visited and visited[current] <= g:
            continue
        
        visited[current] = g

        for neighbor, weight in graph.get(current, []):
            new_g = g + weight
            new_f = new_g + heuristics.get(neighbor, float('inf'))
            heapq.heappush(priority_queue, (new_f, neighbor, path + [neighbor], new_g))

    return None, float('inf')

# 1. Define the Graph (Node: [(neighbor, weight)])
graph = {
    'A': [('B', 1), ('C', 3)],
    'B': [('D', 3)],
    'C': [('D', 1), ('E', 5)],
    'D': [('G', 2)],
    'E': [('G', 1)]
}

# 2. Define Heuristics (Estimated distance to Goal 'G')
heuristics = {
    'A': 6, 'B': 4, 'C': 2, 'D': 1, 'E': 1, 'G': 0
}

start_node = 'A'
goal_node = 'G'

path, total_cost = a_star_search(graph, heuristics, start_node, goal_node)

if path:
    print(f"--- A* Search Results ---")
    print(f"Path found: {' -> '.join(path)}")
    print(f"Total Path Cost: {total_cost}")
else:
    print("No path found.")

    '''
    output:
    --- A* Search Results ---
Path found: A -> C -> D -> G
Total Path Cost: 6
'''