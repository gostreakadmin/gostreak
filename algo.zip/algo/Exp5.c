/*5.Write a C program to implement the depth first search algorithm for a graph and analyse its time complexity.*/

#include <stdio.h>
#include <string.h>

// Function to count the occurrences of a pattern in a text
int countOccurrences(char text[], char pattern[]) {
    int textLength = strlen(text);
    int patternLength = strlen(pattern);
    int count = 0;

    // Loop to slide the pattern across the text one by one
    // We only need to go up to (textLength - patternLength)
    for (int i = 0; i <= textLength - patternLength; i++) {
        int j;

        // For the current index 'i', check for a pattern match
        for (j = 0; j < patternLength; j++) {
            if (text[i + j] != pattern[j]) {
                break; // Mismatch found, break the inner loop
            }
        }

        // If the inner loop completed fully without breaking, 
        // it means j reached patternLength, so we found a match!
        if (j == patternLength) {
            count++;
        }
    }

    return count;
}

int main() {
    char text[1000];
    char pattern[100];

    // Read the longer text
    printf("Enter the longer text string: ");
    // using %[^\n] to read spaces in the string until Enter is pressed
    scanf(" %[^\n]s", text); 

    // Read the shorter pattern
    printf("Enter the pattern to search for: ");
    scanf(" %[^\n]s", pattern);

    // Call the function
    int result = countOccurrences(text, pattern);

    // Display the result
    printf("\nThe pattern '%s' occurs %d time(s) in the text.\n", pattern, result);

    return 0;
}

/*
Enter the longer text string: abracadabra
Enter the pattern to search for: abra

The pattern 'abra' occurs 2 time(s) in the text.
*/