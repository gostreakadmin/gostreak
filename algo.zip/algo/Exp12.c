/*12.Implement Traveling Salesperson problem and then solve the same problem instance using any approximation algorithm and determine the error in the approximation.*/

#include <stdio.h>
#include <limits.h>

int n;
int graph[20][20];
int min_cost_exact = INT_MAX;

// 1. EXACT ALGORITHM: Backtracking to find the true minimum cost
void exactTSP(int curr_pos, int count, int cost, int visited[]) {
    // Base case: If all cities are visited and there is a path back to the start
    if (count == n && graph[curr_pos][0]) {
        if (cost + graph[curr_pos][0] < min_cost_exact) {
            min_cost_exact = cost + graph[curr_pos][0];
        }
        return;
    }

    // Try all unvisited cities
    for (int i = 0; i < n; i++) {
        if (!visited[i] && graph[curr_pos][i]) {
            visited[i] = 1; // Mark as visited
            exactTSP(i, count + 1, cost + graph[curr_pos][i], visited);
            visited[i] = 0; // BACKTRACK: Unmark for the next permutation
        }
    }
}

// 2. APPROXIMATION ALGORITHM: Nearest Neighbor Heuristic
int approxTSP() {
    int visited[20] = {0};
    int cost = 0;
    int curr = 0; // Start at city 0
    visited[0] = 1;

    for (int i = 1; i < n; i++) {
        int next_city = -1;
        int min_edge = INT_MAX;

        // Find the nearest unvisited city
        for (int j = 0; j < n; j++) {
            if (!visited[j] && graph[curr][j] && graph[curr][j] < min_edge) {
                min_edge = graph[curr][j];
                next_city = j;
            }
        }

        // Add edge cost and move to the next city
        cost += min_edge;
        visited[next_city] = 1;
        curr = next_city;
    }

    // Add cost to return to the starting city
    cost += graph[curr][0];
    
    return cost;
}

int main() {
    int visited[20] = {0};

    printf("Enter the number of cities: ");
    scanf("%d", &n);

    printf("Enter the Adjacency Matrix (use 0 for diagonal/no path):\n");
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            scanf("%d", &graph[i][j]);
        }
    }

    // Start exact TSP from City 0
    visited[0] = 1; 
    exactTSP(0, 1, 0, visited);

    // Get Approximation TSP cost
    int approx_cost = approxTSP();

    // Calculate Error
    int abs_error = approx_cost - min_cost_exact;
    float percent_error = ((float)abs_error / min_cost_exact) * 100.0;

    printf("\n--- Results ---\n");
    printf("Exact TSP Minimum Cost : %d\n", min_cost_exact);
    printf("Approximate TSP Cost   : %d\n", approx_cost);
    printf("Absolute Error         : %d\n", abs_error);
    printf("Percentage Error       : %.2f%%\n", percent_error);

    return 0;
}

/*
Enter the number of cities: 4
Enter the Adjacency Matrix (use 0 for diagonal/no path):
0  10 15 20
10  0 8  25
15 8  0  6
20 25 6  0

--- Results ---
Exact TSP Minimum Cost : 44
Approximate TSP Cost   : 44
Absolute Error         : 0
Percentage Error       : 0.00%
*/