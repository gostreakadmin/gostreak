/*4.Write a C function that takes two string inputs – a longer text and a shorter text such that the function should give the total number of occurrences of the pattern in the text string. */

#include <stdio.h>

#define MAX 10 // Maximum size for the matrices

// Function to multiply two matrices
void multiplyMatrices(int r1, int c1, int mat1[MAX][MAX], 
                      int r2, int c2, int mat2[MAX][MAX], 
                      int result[MAX][MAX]) {
                          
    // 1. Initialize the result matrix to 0
    for (int i = 0; i < r1; i++) {
        for (int j = 0; j < c2; j++) {
            result[i][j] = 0;
        }
    }

    // 2. Perform matrix multiplication
    for (int i = 0; i < r1; i++) {
        for (int j = 0; j < c2; j++) {
            for (int k = 0; k < c1; k++) {
                result[i][j] += mat1[i][k] * mat2[k][j];
            }
        }
    }
}

// Function to print a matrix
void printMatrix(int r, int c, int mat[MAX][MAX]) {
    for (int i = 0; i < r; i++) {
        for (int j = 0; j < c; j++) {
            printf("%d\t", mat[i][j]);
        }
        printf("\n");
    }
}

int main() {
    int r1, c1, r2, c2;
    int mat1[MAX][MAX], mat2[MAX][MAX], result[MAX][MAX];

    // Input dimensions for Matrix 1
    printf("Enter rows and columns for first matrix: ");
    scanf("%d %d", &r1, &c1);

    // Input dimensions for Matrix 2
    printf("Enter rows and columns for second matrix: ");
    scanf("%d %d", &r2, &c2);

    // Check if multiplication is possible
    if (c1 != r2) {
        printf("Error: Matrices cannot be multiplied! ");
        printf("Columns of 1st matrix (%d) must equal rows of 2nd matrix (%d).\n", c1, r2);
        return 0; // Exit the program
    }

    // Input elements for Matrix 1
    printf("\nEnter elements of first matrix:\n");
    for (int i = 0; i < r1; i++) {
        for (int j = 0; j < c1; j++) {
            scanf("%d", &mat1[i][j]);
        }
    }

    // Input elements for Matrix 2
    printf("\nEnter elements of second matrix:\n");
    for (int i = 0; i < r2; i++) {
        for (int j = 0; j < c2; j++) {
            scanf("%d", &mat2[i][j]);
        }
    }

    // Call the multiplication function
    multiplyMatrices(r1, c1, mat1, r2, c2, mat2, result);

    // Print the result
    printf("\nResultant Matrix after Multiplication:\n");
    printMatrix(r1, c2, result);

    return 0;
}

/*
Enter rows and columns for first matrix: 2 2
Enter rows and columns for second matrix: 2 2

Enter elements of first matrix:
1 2
3 4

Enter elements of second matrix:
5 6
7 8

Resultant Matrix after Multiplication:
19      22      
43      50
*/