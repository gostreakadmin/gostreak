/*13.Implement randomized algorithms for finding the kth smallest number.*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

// Utility function to swap two integers
void swap(int* a, int* b) {
    int temp = *a;
    *a = *b;
    *b = temp;
}

// Standard partition function (Lomuto partition scheme)
int partition(int arr[], int low, int high) {
    int pivot = arr[high]; // Pivot is the last element
    int i = low;           // Index of smaller element

    for (int j = low; j < high; j++) {
        // If current element is smaller than or equal to pivot
        if (arr[j] <= pivot) {
            swap(&arr[i], &arr[j]);
            i++;
        }
    }
    swap(&arr[i], &arr[high]);
    return i;
}

// Function to pick a random pivot, swap it to the end, and then partition
int randomPartition(int arr[], int low, int high) {
    int n = high - low + 1;
    
    // Generate a random index between low and high
    int pivot_index = low + rand() % n; 
    
    // Swap the randomly chosen pivot with the last element
    swap(&arr[pivot_index], &arr[high]); 
    
    return partition(arr, low, high);
}

// Recursive function to find the kth smallest element
int kthSmallest(int arr[], int low, int high, int k) {
    // If k is within the valid range
    if (k > 0 && k <= high - low + 1) {
        
        // Partition the array around a random pivot
        int pos = randomPartition(arr, low, high);

        // If the pivot's position is exactly the kth element we want
        if (pos - low == k - 1) {
            return arr[pos];
        }

        // If the position is greater, the kth element must be in the LEFT subarray
        if (pos - low > k - 1) {
            return kthSmallest(arr, low, pos - 1, k);
        }

        // Otherwise, the kth element must be in the RIGHT subarray
        // Notice we subtract the number of elements we threw away from 'k'
        return kthSmallest(arr, pos + 1, high, k - pos + low - 1);
    }

    // Return -1 if k is out of bounds
    return -1; 
}

int main() {
    int n, k;

    // Seed the random number generator using current time
    srand(time(0)); 

    printf("Enter the number of elements in the array: ");
    scanf("%d", &n);

    int arr[n];

    printf("Enter %d elements:\n", n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }

    printf("Enter the value of k (e.g., 1 for smallest, 2 for second smallest): ");
    scanf("%d", &k);

    if (k > 0 && k <= n) {
        int result = kthSmallest(arr, 0, n - 1, k);
        printf("The %d-th smallest element is: %d\n", k, result);
    } else {
        printf("Invalid value of k! It must be between 1 and %d\n", n);
    }

    return 0;
}

/*
Enter the number of elements in the array: 6
Enter 6 elements:
7 10 4 3 20 15
Enter the value of k (e.g., 1 for smallest, 2 for second smallest): 3
The 3-th smallest element is: 7
*/