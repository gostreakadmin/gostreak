/*8.Find the minimum cost spanning tree of a given undirected graph using Prim's algorithm.*/#include <stdio.h>
#include <limits.h>
#include <stdbool.h>

// Function to find the vertex with the minimum key value 
// from the set of vertices not yet included in the MST
int minKey(int n, int key[], bool mstSet[]) {
    int min = INT_MAX, min_index;

    for (int v = 0; v < n; v++) {
        if (mstSet[v] == false && key[v] < min) {
            min = key[v];
            min_index = v;
        }
    }
    return min_index;
}

// Function to construct and print the MST using Prim's algorithm
void primMST(int n, int graph[n][n]) {
    int parent[n];  // Array to store the constructed MST (stores the parent of each vertex)
    int key[n];     // Key values used to pick the minimum weight edge
    bool mstSet[n]; // To represent the set of vertices already included in the MST

    // 1. Initialize all keys to INFINITY and mstSet to false
    for (int i = 0; i < n; i++) {
        key[i] = INT_MAX;
        mstSet[i] = false;
    }

    // 2. Always include the first vertex in the MST
    key[0] = 0;      // Make key 0 so this vertex is picked first
    parent[0] = -1;  // First node is always the root of the MST (no parent)

    // 3. The MST will have exactly (n - 1) edges
    for (int count = 0; count < n - 1; count++) {
        
        // Pick the minimum key vertex from the set of vertices not yet in the MST
        int u = minKey(n, key, mstSet);

        // Add the picked vertex to the MST set
        mstSet[u] = true;

        // Update key value and parent index of all adjacent vertices of the picked vertex.
        for (int v = 0; v < n; v++) {
            // graph[u][v] is non-zero only for adjacent vertices
            // mstSet[v] is false for vertices not yet included
            // Update the key only if the graph[u][v] is smaller than current key[v]
            if (graph[u][v] && mstSet[v] == false && graph[u][v] < key[v]) {
                parent[v] = u;
                key[v] = graph[u][v];
            }
        }
    }

    // 4. Print the constructed MST and calculate the minimum cost
    int min_cost = 0;
    printf("\nMinimum Spanning Tree (MST):\n");
    printf("Edge \tWeight\n");
    for (int i = 1; i < n; i++) {
        printf("%d - %d \t%d \n", parent[i], i, graph[i][parent[i]]);
        min_cost += graph[i][parent[i]];
    }
    printf("\nTotal Minimum Cost of Spanning Tree: %d\n", min_cost);
}

int main() {
    int n;

    printf("Enter the number of vertices in the graph: ");
    scanf("%d", &n);

    int graph[n][n];

    printf("Enter the adjacency matrix (row by row, use 0 for no edge/diagonal):\n");
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            scanf("%d", &graph[i][j]);
        }
    }

    // Call Prim's algorithm
    primMST(n, graph);

    return 0;
}

/*
Enter the number of vertices in the graph: 5
Enter the adjacency matrix (row by row, use 0 for no edge/diagonal):
0 2 0 6 0
2 0 3 8 5
0 3 0 0 7
6 8 0 0 9
0 5 7 9 0

Minimum Spanning Tree (MST):
Edge    Weight
0 - 1   2 
1 - 2   3 
0 - 3   6 
1 - 4   5 

Total Minimum Cost of Spanning Tree: 16
*/