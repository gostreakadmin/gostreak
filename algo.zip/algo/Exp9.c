/*9.Implement Floyd's algorithm for the All-Pairs-Shortest-Paths problem.*/

#include <stdio.h>

#define INF 99999 // Represent infinity for vertices not connected directly

// Function to print the solution matrix
void printSolution(int n, int dist[n][n]) {
    printf("\nShortest Path Matrix (All-Pairs):\n");
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            if (dist[i][j] == INF) {
                printf("%7s", "INF");
            } else {
                printf("%7d", dist[i][j]);
            }
        }
        printf("\n");
    }
}

// Function to implement Floyd's Algorithm
void floydWarshall(int n, int graph[n][n]) {
    int dist[n][n];

    // 1. Initialize the solution matrix same as input graph matrix
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            dist[i][j] = graph[i][j];
        }
    }

    // 2. Core Floyd-Warshall Algorithm
    // k is the intermediate vertex
    for (int k = 0; k < n; k++) {
        // i is the source vertex
        for (int i = 0; i < n; i++) {
            // j is the destination vertex
            for (int j = 0; j < n; j++) {
                // If vertex k is on the shortest path from i to j,
                // then update the value of dist[i][j]
                if (dist[i][k] + dist[k][j] < dist[i][j]) {
                    dist[i][j] = dist[i][k] + dist[k][j];
                }
            }
        }
    }

    // 3. Print the shortest distance matrix
    printSolution(n, dist);
}

int main() {
    int n;

    printf("Enter the number of vertices in the graph: ");
    scanf("%d", &n);

    int graph[n][n];

    printf("Enter the adjacency matrix (use %d to represent INF / no direct edge):\n", INF);
    printf("Note: Distance from a vertex to itself should be 0.\n");
    
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            scanf("%d", &graph[i][j]);
        }
    }

    // Call the function to compute all-pairs shortest paths
    floydWarshall(n, graph);

    return 0;
}

/*
Enter the number of vertices in the graph: 4
Enter the adjacency matrix (use 99999 to represent INF / no direct edge):
Note: Distance from a vertex to itself should be 0.
0       5       99999   10
99999   0       3       99999
99999   99999   0       1
99999   99999   99999   0

Shortest Path Matrix (All-Pairs):
      0      5      8      9
    INF      0      3      4
    INF    INF      0      1
    INF    INF    INF      0
*/