/*7.Develop a program to implement graph traversal using Breadth First Search.*/

#include <stdio.h>

#define MAX 20 // Maximum number of vertices

// Global variables for the Queue
int queue[MAX];
int front = -1, rear = -1;

// Function to add an item to the queue
void enqueue(int vertex) {
    if (rear == MAX - 1) {
        return; // Queue is full
    }
    if (front == -1) {
        front = 0;
    }
    rear++;
    queue[rear] = vertex;
}

// Function to remove an item from the queue
int dequeue() {
    if (front == -1 || front > rear) {
        return -1; // Queue is empty
    }
    int vertex = queue[front];
    front++;
    return vertex;
}

// Function to check if the queue is empty
int isEmpty() {
    if (front == -1 || front > rear) {
        return 1; // True
    }
    return 0; // False
}

// Function to perform BFS traversal
void bfs(int n, int graph[MAX][MAX], int startVertex) {
    int visited[MAX] = {0}; // Array to keep track of visited vertices

    printf("BFS Traversal: ");

    // 1. Start by enqueueing the starting vertex and marking it as visited
    enqueue(startVertex);
    visited[startVertex] = 1;

    // 2. Loop until the queue is empty
    while (!isEmpty()) {
        // Dequeue a vertex and print it
        int current = dequeue();
        printf("%d ", current);

        // 3. Find all unvisited adjacent vertices of the current vertex
        for (int i = 0; i < n; i++) {
            // If there is an edge AND the vertex hasn't been visited yet
            if (graph[current][i] == 1 && !visited[i]) {
                enqueue(i);
                visited[i] = 1; // Mark as visited as soon as it goes into the queue
            }
        }
    }
    printf("\n");
}

int main() {
    int n, start;
    int graph[MAX][MAX];

    printf("Enter the number of vertices in the graph: ");
    scanf("%d", &n);

    printf("Enter the adjacency matrix (row by row, use 1 for edge, 0 for no edge):\n");
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            scanf("%d", &graph[i][j]);
        }
    }

    printf("Enter the starting vertex (0 to %d): ", n - 1);
    scanf("%d", &start);

    // Call the BFS function
    bfs(n, graph, start);

    return 0;
}

/*
Enter the number of vertices in the graph: 5
Enter the adjacency matrix (row by row, use 1 for edge, 0 for no edge):
0 1 1 0 0
1 0 0 1 1
1 0 0 0 0
0 1 0 0 0
0 1 0 0 0
Enter the starting vertex (0 to 4): 0
BFS Traversal: 0 1 2 3 4
*/