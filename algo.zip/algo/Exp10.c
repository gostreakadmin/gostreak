/*10.Implement the merge sort algorithm in C and analyse its time complexity.*/

#include <stdio.h>

// Function to merge two sorted subarrays into a single sorted array
void merge(int arr[], int l, int m, int r) {
    int i, j, k;
    int n1 = m - l + 1; // Size of left subarray
    int n2 = r - m;     // Size of right subarray

    // Create temporary arrays
    int L[n1], R[n2];

    // Copy data to temporary arrays L[] and R[]
    for (i = 0; i < n1; i++)
        L[i] = arr[l + i];
    for (j = 0; j < n2; j++)
        R[j] = arr[m + 1 + j];

    // Merge the temp arrays back into arr[l..r]
    i = 0; // Initial index of first subarray (L)
    j = 0; // Initial index of second subarray (R)
    k = l; // Initial index of merged subarray (arr)

    while (i < n1 && j < n2) {
        if (L[i] <= R[j]) {
            arr[k] = L[i];
            i++;
        } else {
            arr[k] = R[j];
            j++;
        }
        k++;
    }

    // Copy any remaining elements of L[]
    while (i < n1) {
        arr[k] = L[i];
        i++;
        k++;
    }

    // Copy any remaining elements of R[]
    while (j < n2) {
        arr[k] = R[j];
        j++;
        k++;
    }
}

// Recursive function to sort arr[l..r] using merge()
void mergeSort(int arr[], int l, int r) {
    if (l < r) {
        // Find the middle point to divide the array into two halves
        // Using l + (r - l) / 2 avoids overflow for large l and r
        int m = l + (r - l) / 2;

        // Recursively sort the first and second halves
        mergeSort(arr, l, m);
        mergeSort(arr, m + 1, r);

        // Merge the sorted halves back together
        merge(arr, l, m, r);
    }
}

// Function to print the array
void printArray(int arr[], int size) {
    for (int i = 0; i < size; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");
}

int main() {
    int n;

    printf("Enter the number of elements in the array: ");
    scanf("%d", &n);

    int arr[n];

    printf("Enter %d elements:\n", n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }

    printf("\nUnsorted Array: \n");
    printArray(arr, n);

    // Call mergeSort on the entire array (indices 0 to n-1)
    mergeSort(arr, 0, n - 1);

    printf("\nSorted Array: \n");
    printArray(arr, n);

    return 0;
}

/*
Enter the number of elements in the array: 7
Enter 7 elements:
38 27 43 3 9 82 10

Unsorted Array: 
38 27 43 3 9 82 10 

Sorted Array: 
3 9 10 27 38 43 82
*/