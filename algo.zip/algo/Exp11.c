/*11.Implement quick sort algorithm and analyse its time complexity.*/

#include <stdio.h>

// Utility function to swap two elements
void swap(int* a, int* b) {
    int temp = *a;
    *a = *b;
    *b = temp;
}

// Function to partition the array on the basis of pivot element
int partition(int arr[], int low, int high) {
    // Select the last element as the pivot
    int pivot = arr[high]; 
    
    // Index of smaller element, indicates the right position of pivot found so far
    int i = (low - 1); 

    for (int j = low; j < high; j++) {
        // If current element is smaller than the pivot
        if (arr[j] < pivot) {
            i++; // Increment index of smaller element
            swap(&arr[i], &arr[j]);
        }
    }
    // Swap the pivot element with the element at (i + 1)
    // so the pivot is placed in its correct sorted position
    swap(&arr[i + 1], &arr[high]);
    
    return (i + 1); // Return the partitioning index
}

// The main function that implements QuickSort
void quickSort(int arr[], int low, int high) {
    if (low < high) {
        // pi is partitioning index, arr[pi] is now at right place
        int pi = partition(arr, low, high);

        // Separately sort elements before partition and after partition
        quickSort(arr, low, pi - 1);
        quickSort(arr, pi + 1, high);
    }
}

// Function to print the array
void printArray(int arr[], int size) {
    for (int i = 0; i < size; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");
}

int main() {
    int n;

    printf("Enter the number of elements in the array: ");
    scanf("%d", &n);

    int arr[n];

    printf("Enter %d elements:\n", n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }

    printf("\nUnsorted Array: \n");
    printArray(arr, n);

    // Call quickSort on the entire array
    quickSort(arr, 0, n - 1);

    printf("\nSorted Array: \n");
    printArray(arr, n);

    return 0;
}

/*
Enter the number of elements in the array: 6
Enter 6 elements:
10 7 8 9 1 5

Unsorted Array: 
10 7 8 9 1 5 

Sorted Array: 
1 5 7 8 9 10
*/