/*1.Write a C program to implement linear search and analyse its time complexity.*/

#include <stdio.h>

// Function to perform linear search
int linearSearch(int arr[], int n, int key) {
    // Traverse the array element by element
    for (int i = 0; i < n; i++) {
        if (arr[i] == key) {
            return i; // Return the index if the key is found
        }
    }
    return -1; // Return -1 if the key is not found after checking all elements
}

int main() {
    int n, key, result;

    // 1. Get the size of the array
    printf("Enter the number of elements in the array: ");
    scanf("%d", &n);

    int arr[n]; 

    // 2. Get the array elements from the user
    printf("Enter %d elements:\n", n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }

    // 3. Get the element to search for
    printf("Enter the element to search: ");
    scanf("%d", &key);

    // 4. Call the search function
    result = linearSearch(arr, n, key);

    // 5. Display the result
    if (result != -1) {
        printf("Element %d found at index %d.\n", key, result);
    } else {
        printf("Element %d not found in the array.\n", key);
    }

    return 0;
}

/*
Enter the number of elements in the array: 5
Enter 5 elements:
10 25 30 45 50
Enter the element to search: 30
Element 30 found at index 2.
*/