/*15.Write a C program to Implement N Queens problem using Backtracking.*/

#include <stdio.h>
#include <stdbool.h>

int n; // Global variable for board size

// Function to print the board
void printSolution(int board[20][20]) {
    printf("One possible placement for %d Queens:\n", n);
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            if (board[i][j] == 1)
                printf(" Q "); // Q represents a Queen
            else
                printf(" . "); // . represents an empty space
        }
        printf("\n");
    }
}

// Function to check if it's safe to place a queen at board[row][col]
bool isSafe(int board[20][20], int row, int col) {
    int i, j;

    // 1. Check the same column in previous rows
    for (i = 0; i < row; i++) {
        if (board[i][col]) return false;
    }

    // 2. Check upper left diagonal
    for (i = row, j = col; i >= 0 && j >= 0; i--, j--) {
        if (board[i][j]) return false;
    }

    // 3. Check upper right diagonal
    for (i = row, j = col; i >= 0 && j < n; i--, j++) {
        if (board[i][j]) return false;
    }

    return true; // If no conflicts, it's safe
}

// Recursive function to solve N-Queens using backtracking
bool solveNQUtil(int board[20][20], int row) {
    // Base case: If all queens are placed successfully
    if (row >= n) {
        return true; 
    }

    // Try placing a queen in all columns one by one for the current row
    for (int col = 0; col < n; col++) {
        // Check if the queen can be placed safely
        if (isSafe(board, row, col)) {
            board[row][col] = 1; // Place the queen

            // Recur to place the rest of the queens
            if (solveNQUtil(board, row + 1)) {
                return true;
            }

            // BACKTRACKING: If placing queen here doesn't lead to a solution,
            // remove the queen and try the next column
            board[row][col] = 0; 
        }
    }

    // If the queen cannot be placed in any column in this row, return false
    return false; 
}

int main() {
    int board[20][20] = {0}; // Initialize the board with 0s

    printf("Enter the value of N (number of queens): ");
    scanf("%d", &n);

    // N=2 and N=3 have no solutions
    if (n == 2 || n == 3) {
        printf("Solution does not exist for N = %d\n", n);
        return 0;
    }

    if (solveNQUtil(board, 0) == false) {
        printf("Solution does not exist\n");
    } else {
        printSolution(board);
    }

    return 0;
}

/*
Enter the value of N (number of queens): 4
One possible placement for 4 Queens:
 .  Q  .  . 
 .  .  .  Q 
 Q  .  .  . 
 .  .  Q  .
 */