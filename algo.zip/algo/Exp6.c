/*6.Write a C program to implement the depth first search algorithm for a graph and analyse its time complexity.*/

#include <stdio.h>

#define MAX 20 // Maximum number of vertices

// Global variables to make recursion easier
int graph[MAX][MAX];
int visited[MAX];
int n; // Number of vertices

// Recursive function to perform DFS
void dfs(int vertex) {
    // 1. Print the current vertex and mark it as visited
    printf("%d ", vertex);
    visited[vertex] = 1;

    // 2. Visit all adjacent unvisited vertices
    for (int i = 0; i < n; i++) {
        // If there is an edge AND the vertex hasn't been visited yet
        if (graph[vertex][i] == 1 && !visited[i]) {
            dfs(i); // Recursively call DFS for the adjacent vertex
        }
    }
}

int main() {
    int start;

    printf("Enter the number of vertices in the graph: ");
    scanf("%d", &n);

    // Initialize visited array to 0
    for (int i = 0; i < n; i++) {
        visited[i] = 0;
    }

    printf("Enter the adjacency matrix (row by row, use 1 for edge, 0 for no edge):\n");
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            scanf("%d", &graph[i][j]);
        }
    }

    printf("Enter the starting vertex (0 to %d): ", n - 1);
    scanf("%d", &start);

    printf("DFS Traversal: ");
    
    // Call the recursive DFS function
    dfs(start);
    
    printf("\n");

    return 0;
}

/*
Enter the number of vertices in the graph: 5
Enter the adjacency matrix (row by row, use 1 for edge, 0 for no edge):
0 1 1 0 0
1 0 0 1 0
1 0 0 0 1
0 1 0 0 0
0 0 1 0 0
Enter the starting vertex (0 to 4): 0
DFS Traversal: 0 1 3 2 4
*/