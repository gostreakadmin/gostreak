/*2.Write a program to implement binary search in C. Demonstrate the working of the algorithm with suitable inputs and analyse its time complexity.*/

#include <stdio.h>

// Function to perform binary search
int binarySearch(int arr[], int n, int key) {
    int low = 0;
    int high = n - 1;

    while (low <= high) {
        // Find the middle index. Using (low + (high - low) / 2) prevents integer overflow
        int mid = low + (high - low) / 2;

        // Check if the key is present at the middle
        if (arr[mid] == key) {
            return mid; 
        }

        // If the key is greater, ignore the left half
        if (arr[mid] < key) {
            low = mid + 1;
        }
        // If the key is smaller, ignore the right half
        else {
            high = mid - 1;
        }
    }

    // Key was not found
    return -1;
}

int main() {
    int n, key, result;

    printf("Enter the number of elements in the array: ");
    scanf("%d", &n);

    int arr[n];

    // Remind the user to enter sorted elements
    printf("Enter %d elements in SORTED (ascending) order:\n", n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }

    printf("Enter the element to search: ");
    scanf("%d", &key);

    // Call the binary search function
    result = binarySearch(arr, n, key);

    if (result != -1) {
        printf("Element %d found at index %d.\n", key, result);
    } else {
        printf("Element %d not found in the array.\n", key);
    }

    return 0;
}

/*
Enter the number of elements in the array: 6
Enter 6 elements in SORTED (ascending) order:
4 8 15 16 23 42
Enter the element to search: 16
Element 16 found at index 3.
*/