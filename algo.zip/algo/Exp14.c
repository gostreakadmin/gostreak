/*14.Compute the transitive closure of a given directed graph using Warshall's algorithm.*/

#include <stdio.h>

// Function to print the reachability matrix
void printMatrix(int n, int reach[n][n]) {
    printf("\nTransitive Closure (Reachability Matrix):\n");
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            printf("%d ", reach[i][j]);
        }
        printf("\n");
    }
}

// Function to compute the transitive closure
void warshall(int n, int graph[n][n]) {
    int reach[n][n];

    // 1. Initialize the reach matrix to be the same as the input graph matrix
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            reach[i][j] = graph[i][j];
        }
    }

    // 2. Core Warshall's Algorithm
    // k is the intermediate vertex
    for (int k = 0; k < n; k++) {
        // i is the source vertex
        for (int i = 0; i < n; i++) {
            // j is the destination vertex
            for (int j = 0; j < n; j++) {
                // Reachability is true if there is a direct path (reach[i][j]) OR
                // a path through the intermediate vertex k (reach[i][k] AND reach[k][j])
                reach[i][j] = reach[i][j] || (reach[i][k] && reach[k][j]);
            }
        }
    }

    // 3. Print the final matrix
    printMatrix(n, reach);
}

int main() {
    int n;

    printf("Enter the number of vertices in the graph: ");
    scanf("%d", &n);

    int graph[n][n];

    printf("Enter the adjacency matrix (row by row, use 1 for edge, 0 for no edge):\n");
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            scanf("%d", &graph[i][j]);
        }
    }

    // Call the function to compute transitive closure
    warshall(n, graph);

    return 0;
}

/*
Enter the number of vertices in the graph: 4
Enter the adjacency matrix (row by row, use 1 for edge, 0 for no edge):
0 1 0 0
0 0 1 0
0 0 0 1
0 0 0 0

Transitive Closure (Reachability Matrix):
0 1 1 1 
0 0 1 1 
0 0 0 1 
0 0 0 0
*/